<?php
$DB_TYPE = 'sqlite';  // Using SQLite instead of MySQL

// MySQL credentials (not used when DB_TYPE is sqlite)
$MYSQL_HOST = 'localhost';
$MYSQL_DB   = 'planejamentoepro_pp';
$MYSQL_USER = 'planejamentoepro_pp';
$MYSQL_PASS = 'Oliveira2001';
$MYSQL_PORT = '3306';

$ENCRYPTION_KEY = 'your-secret-encryption-key-change-this-to-something-unique-and-long';
