<?php
require __DIR__ . '/_bootstrap.php';
$uid = require_auth();
$method = $_SERVER['REQUEST_METHOD'];

if($method==='GET'){
  $project_id = intval($_GET['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  if(!can_access_project($pdo,$project_id,$uid,false)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('SELECT id,project_id,seq,name,start,end,duration,durationHours,percent,rels_json,anchor,cost_est,cost_act,diff,weight_mode,critical,actual_start_date,actual_end_date,progress_update_date FROM tasks WHERE project_id=? ORDER BY seq ASC');
  $s->execute([$project_id]);
  $rows=$s->fetchAll(PDO::FETCH_ASSOC);
  foreach($rows as &$r){ $r['rels']=json_decode($r['rels_json']?:'[]',true); unset($r['rels_json']); }
  ok(['tasks'=>$rows]);
}

$d = body_json();

if($method==='POST'){
  $project_id = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $pdo->exec('UPDATE projects SET task_seq = task_seq + 1 WHERE id=' . $project_id);
  $s=$pdo->prepare('SELECT task_seq FROM projects WHERE id=?'); $s->execute([$project_id]); $seq=intval($s->fetchColumn());
  $rels_json = json_encode($d['rels'] ?? []);
  $s=$pdo->prepare('INSERT INTO tasks(project_id,seq,name,start,end,duration,durationHours,percent,rels_json,anchor,cost_est,cost_act,diff,weight_mode,critical,actual_start_date,actual_end_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,?,?)');
  $s->execute([$project_id,$seq,$d['name']??'',$d['start']??null,$d['end']??null,$d['duration']??null,$d['durationHours']??0,$d['percent']??0,$rels_json,$d['anchor']??'',$d['costEst']??0,$d['costAct']??0,$d['diff']??1,$d['weightMode']??'time',$d['actualStartDate']??null,$d['actualEndDate']??null]);
  ok(['seq'=>$seq]);
}

if($method==='PUT'){
  $project_id = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $seq = intval($d['seq'] ?? 0);
  $rels_json = json_encode($d['rels'] ?? []);
  $s=$pdo->prepare('UPDATE tasks SET name=?, start=?, end=?, duration=?, durationHours=?, percent=?, rels_json=?, anchor=?, cost_est=?, cost_act=?, diff=?, weight_mode=?, critical=?, updated_at=CURRENT_TIMESTAMP, progress_update_date=?, actual_start_date=?, actual_end_date=? WHERE project_id=? AND seq=?');
  $s->execute([$d['name']??'',$d['start']??null,$d['end']??null,$d['duration']??null,$d['durationHours']??0,$d['percent']??0,$rels_json,$d['anchor']??'',$d['costEst']??0,$d['costAct']??0,$d['diff']??1,$d['weightMode']??'time',intval($d['critical']??0),$d['progressUpdateDate']??null,$d['actualStartDate']??null,$d['actualEndDate']??null,$project_id,$seq]);
  ok(['ok'=>true]);
}

if($method==='DELETE'){
  $project_id = intval($_GET['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $seq = intval($_GET['seq'] ?? 0);
  $s=$pdo->prepare('DELETE FROM tasks WHERE project_id=? AND seq=?'); $s->execute([$project_id,$seq]);
  ok(['ok'=>true]);
}
