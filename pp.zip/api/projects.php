<?php
require __DIR__ . '/_bootstrap.php';
$uid = require_auth();
$method = $_SERVER['REQUEST_METHOD'];

if($method==='GET'){
  // Projetos onde é owner OU membro
  $sql = "SELECT DISTINCT p.*
          FROM projects p
          LEFT JOIN project_members m ON m.project_id = p.id
          WHERE p.owner_id=? OR m.user_id=?
          ORDER BY p.id DESC";
  $s=$pdo->prepare($sql); $s->execute([$uid,$uid]);
  ok(['projects'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
}

$d = body_json();
if($method==='POST'){
  $s=$pdo->prepare('INSERT INTO projects(owner_id,name,code,start_date,end_date,status,calendar_type,hours_per_day,days_per_week,consider_holidays,holidays_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  $s->execute([
    $uid,
    $d['name']??'',
    $d['code']??'',
    $d['startDate']??null,
    $d['endDate']??null,
    $d['status']??'PLANNED',
    $d['calendarType']??'standard',
    $d['hoursPerDay']??8,
    $d['daysPerWeek']??5,
    $d['considerHolidays']??1,
    $d['holidaysJson']??null
  ]);
  $pid = intval($pdo->lastInsertId());
  // owner vira admin no project_members
  $pdo->prepare('INSERT OR IGNORE INTO project_members(project_id,user_id,role) VALUES(?,?,?)')->execute([$pid,$uid,'admin']);
  ok(['id'=>$pid]);
}
if($method==='PUT'){
  $id=intval($d['id']??0);
  if(!can_access_project($pdo,$id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('UPDATE projects SET name=?, code=?, start_date=?, end_date=?, status=?, calendar_type=?, hours_per_day=?, days_per_week=?, consider_holidays=?, holidays_json=? WHERE id=?');
  $s->execute([
    $d['name']??'',
    $d['code']??'',
    $d['startDate']??null,
    $d['endDate']??null,
    $d['status']??'PLANNED',
    $d['calendarType']??'standard',
    $d['hoursPerDay']??8,
    $d['daysPerWeek']??5,
    $d['considerHolidays']??1,
    $d['holidaysJson']??null,
    $id
  ]);
  ok(['ok'=>true]);
}
if($method==='DELETE'){
  $id=intval($_GET['id']??0);
  if(!can_access_project($pdo,$id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('DELETE FROM projects WHERE id=? AND owner_id=?'); $s->execute([$id,$uid]); // apenas owner pode deletar
  ok(['ok'=>true]);
}
