<?php
require __DIR__ . '/_bootstrap.php';
$uid = require_auth();
$method = $_SERVER['REQUEST_METHOD'];

if($method==='GET'){
  $pid = intval($_GET['project_id'] ?? 0);
  if(!can_access_project($pdo,$pid,$uid,false)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('SELECT m.user_id, m.role, u.name, u.email FROM project_members m JOIN users u ON u.id=m.user_id WHERE m.project_id=? ORDER BY u.name');
  $s->execute([$pid]); ok(['members'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
}

$d = body_json();
if($method==='POST'){
  $pid = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$pid,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $email = strtolower(trim($d['email'] ?? ''));
  $role  = $d['role'] ?? 'viewer';
  $s=$pdo->prepare('SELECT id FROM users WHERE email=?'); $s->execute([$email]); $u=$s->fetchColumn();
  if(!$u){ http_response_code(400); echo json_encode(['error'=>'user_not_found']); exit; }
  $pdo->prepare('INSERT OR REPLACE INTO project_members(project_id,user_id,role) VALUES(?,?,?)')->execute([$pid,intval($u),$role]);
  ok(['ok'=>true]);
}

if($method==='PUT'){
  $pid = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$pid,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $member_id = intval($d['user_id'] ?? 0);
  $role = $d['role'] ?? 'viewer';
  $s=$pdo->prepare('UPDATE project_members SET role=? WHERE project_id=? AND user_id=?');
  $s->execute([$role,$pid,$member_id]); ok(['ok'=>true]);
}

if($method==='DELETE'){
  $pid = intval($_GET['project_id'] ?? 0);
  $member_id = intval($_GET['user_id'] ?? 0);
  if(!can_access_project($pdo,$pid,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('DELETE FROM project_members WHERE project_id=? AND user_id=?'); $s->execute([$pid,$member_id]);
  ok(['ok'=>true]);
}
