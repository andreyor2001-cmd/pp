<?php
error_reporting(0);
ini_set('display_errors', '0');
ob_start();

require __DIR__ . '/_bootstrap.php';

ob_clean();

if (!empty($_SESSION['user_id'])) {
  ok(['user'=>get_user($pdo, intval($_SESSION['user_id']))]);
} else {
  ok(['user'=>null]);
}
