<?php
// pp/api/bootstrap.php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

/*
|---------------------------------------------------------------------
| Sessão (escopo do subdiretório /pp)
|---------------------------------------------------------------------
| Se o app NÃO estiver em /pp, ajuste o path abaixo.
*/
$cookieParams = session_get_cookie_params();
session_set_cookie_params([
  'lifetime' => 0,
  'path' => '/pp',                  // <— ajuste se necessário
  'domain' => $cookieParams['domain'],
  'secure' => !empty($_SERVER['HTTPS']),
  'httponly' => true,
  'samesite' => 'Lax',
]);
session_start();

/*
|---------------------------------------------------------------------
| Proteção do output: evita ruído no JSON e captura erros fatais
|---------------------------------------------------------------------
*/
ob_start();
ini_set('display_errors', '0');     // não vaze warnings no JSON
error_reporting(E_ALL);
set_error_handler(function($severity, $message, $file, $line) {
  throw new ErrorException($message, 0, $severity, $file, $line);
});
register_shutdown_function(function() {
  $err = error_get_last();
  if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
    while (ob_get_level()) { ob_end_clean(); }
    http_response_code(500);
    echo json_encode(['error' => 'fatal']);
  }
});

/*
|---------------------------------------------------------------------
| Conexão MySQL (ajuste DB/USER/PASS conforme cPanel)
|---------------------------------------------------------------------
| Em cPanel, DB e USER costumam ter prefixo (ex.: cprefix_nome).
*/
$DB_HOST = 'localhost';
$DB_PORT = '3306';
$DB_NAME = 'planejamentoepro_pp';   // <— CONFIRME se tem prefixo no cPanel
$DB_USER = 'planejamentoepro_pp';   // <— CONFIRME se tem prefixo no cPanel
$DB_PASS = 'Oliveira2001';          // <— senha do usuário MySQL

$dsn = "mysql:host={$DB_HOST};port={$DB_PORT};dbname={$DB_NAME};charset=utf8mb4";

try {
  $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Throwable $e) {
  while (ob_get_level()) { ob_end_clean(); }
  http_response_code(500);
  echo json_encode(['error' => 'db_connect_failed']);
  exit;
}

/*
|---------------------------------------------------------------------
| Helpers
|---------------------------------------------------------------------
*/
function body_json(): array {
  // tenta JSON no corpo
  $raw = file_get_contents('php://input');
  if ($raw !== false && $raw !== '') {
    $data = json_decode($raw, true);
    if (json_last_error() === JSON_ERROR_NONE && is_array($data)) {
      return $data;
    }
  }
  // fallback: form-urlencoded
  if (!empty($_POST)) return $_POST;
  // fallback: querystring
  if (!empty($_GET))  return $_GET;
  return [];
}

/**
 * Finaliza a resposta garantindo JSON limpo (sem ruído).
 */
function ok(array $data = []): void {
  while (ob_get_level()) { ob_end_clean(); }
  echo json_encode($data);
  exit;
}

/** Busca usuário básico (id, name, email). */
function get_user(PDO $pdo, int $uid): array {
  $s = $pdo->prepare('SELECT id, name, email FROM users WHERE id = ? LIMIT 1');
  $s->execute([$uid]);
  return $s->fetch() ?: [];
}

/** Exige sessão e retorna o usuário. */
function require_user(PDO $pdo): array {
  if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    ok(['error' => 'unauthorized']);
  }
  return get_user($pdo, (int)$_SESSION['user_id']);
}

/*
|---------------------------------------------------------------------
| DICA DE DIAGNÓSTICO (opcional, TEMPORÁRIO):
|---------------------------------------------------------------------
| Se precisar ver o erro real de conexão, troque temporariamente o catch acima por:
|
| } catch (Throwable $e) {
|   while (ob_get_level()) { ob_end_clean(); }
|   http_response_code(500);
|   echo json_encode(['error' => 'db_connect_failed', 'hint' => $e->getMessage()]);
|   exit;
| }
|
| Depois de corrigir as credenciais, VOLTE para a versão sem 'hint'.
*/
