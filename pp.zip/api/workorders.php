<?php
require __DIR__ . '/_bootstrap.php';
$uid = require_auth();
$method = $_SERVER['REQUEST_METHOD'];

if($method==='GET'){
  $project_id = intval($_GET['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('SELECT * FROM projects WHERE id=? AND owner_id=?'); $s->execute([$project_id,$uid]);
  if(!$s->fetch()){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('SELECT * FROM workorders WHERE project_id=? ORDER BY seq ASC'); $s->execute([$project_id]);
  ok(['workorders'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
}

$d = body_json();

if($method==='POST'){
  $project_id = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $pdo->exec('UPDATE projects SET wo_seq = wo_seq + 1 WHERE id=' . $project_id);
  $s=$pdo->prepare('SELECT wo_seq FROM projects WHERE id=?'); $s->execute([$project_id]); $seq=intval($s->fetchColumn());
  $s=$pdo->prepare('INSERT INTO workorders(project_id,seq,title,description,priority,status,owner,start,end,task_seq_ref) VALUES(?,?,?,?,?,?,?,?,?,?)');
  $s->execute([$project_id,$seq,$d['title']??'',$d['desc']??'',$d['priority']??'Média',$d['status']??'Aberta',$d['owner']??'',$d['start']??null,$d['end']??null,$d['taskId']??null]);
  ok(['seq'=>$seq]);
}

if($method==='PUT'){
  $project_id = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $seq = intval($d['seq'] ?? 0);
  $s=$pdo->prepare('UPDATE workorders SET title=?, description=?, priority=?, status=?, owner=?, start=?, end=?, task_seq_ref=?, updated_at=CURRENT_TIMESTAMP WHERE project_id=? AND seq=?');
  $s->execute([$d['title']??'',$d['desc']??'',$d['priority']??'Média',$d['status']??'Aberta',$d['owner']??'',$d['start']??null,$d['end']??null,$d['taskId']??null,$project_id,$seq]);
  ok(['ok'=>true]);
}

if($method==='DELETE'){
  $project_id = intval($_GET['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $seq = intval($_GET['seq'] ?? 0);
  $s=$pdo->prepare('DELETE FROM workorders WHERE project_id=? AND seq=?'); $s->execute([$project_id,$seq]);
  ok(['ok'=>true]);
}
