<?php
// Encryption utilities for sensitive data

function encrypt_data($data, $key) {
    if (empty($data)) return $data;
    
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', hash('sha256', $key), 0, $iv);
    
    // Combine IV and encrypted data
    return base64_encode($iv . $encrypted);
}

function decrypt_data($encrypted_data, $key) {
    if (empty($encrypted_data)) return $encrypted_data;
    
    try {
        $data = base64_decode($encrypted_data);
        $iv_length = openssl_cipher_iv_length('aes-256-cbc');
        $iv = substr($data, 0, $iv_length);
        $encrypted = substr($data, $iv_length);
        
        return openssl_decrypt($encrypted, 'aes-256-cbc', hash('sha256', $key), 0, $iv);
    } catch (Exception $e) {
        return $encrypted_data; // Return original if decryption fails
    }
}

// Helper to encrypt sensitive fields in arrays
function encrypt_sensitive_fields($data, $fields, $key) {
    foreach ($fields as $field) {
        if (isset($data[$field]) && !empty($data[$field])) {
            $data[$field] = encrypt_data($data[$field], $key);
        }
    }
    return $data;
}

// Helper to decrypt sensitive fields in arrays
function decrypt_sensitive_fields($data, $fields, $key) {
    foreach ($fields as $field) {
        if (isset($data[$field]) && !empty($data[$field])) {
            $data[$field] = decrypt_data($data[$field], $key);
        }
    }
    return $data;
}
