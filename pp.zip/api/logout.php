<?php
error_reporting(0);
ini_set('display_errors', '0');
ob_start();

require __DIR__ . '/_bootstrap.php';

ob_clean();

$_SESSION = [];
if (ini_get('session.use_cookies')) {
  $p = session_get_cookie_params();
  setcookie(session_name(), '', time()-42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
ok(['ok'=>true]);
