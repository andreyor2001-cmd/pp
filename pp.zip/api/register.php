<?php
error_reporting(0);
ini_set('display_errors', '0');

// Start output buffering to catch any accidental output
ob_start();

require __DIR__ . '/_bootstrap.php';

// Clear any accidental output
ob_clean();

// Get raw input
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

// If JSON decode failed, try to get from POST
if (!is_array($data)) {
    $data = $_POST;
}

$name  = trim($data['name'] ?? '');
$email = strtolower(trim($data['email'] ?? ''));
$pass  = strval($data['password'] ?? '');

if (!$email || !$pass) { 
    http_response_code(400); 
    ok(['error'=>'missing_fields']); 
}

try{
  $s=$pdo->prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)');
  $s->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);
  $_SESSION['user_id'] = intval($pdo->lastInsertId());
  ok(['user'=>get_user($pdo,$_SESSION['user_id'])]);
}catch(PDOException $e){
  if ($e->getCode()==='23000' || strpos($e->getMessage(), 'UNIQUE') !== false) { 
    http_response_code(400); 
    ok(['error'=>'email_in_use']); 
  }
  http_response_code(500); 
  ok(['error'=>'register_failed', 'message' => $e->getMessage()]);
}
