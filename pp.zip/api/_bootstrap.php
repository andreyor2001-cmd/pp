<?php
declare(strict_types=1);

error_reporting(0);
ini_set('display_errors', '0');
ob_start();

session_start();
header('Content-Type: application/json; charset=utf-8');

require __DIR__ . '/config.php';
require __DIR__ . '/encryption.php';

try {
  if ($DB_TYPE === 'mysql') {
    $dsn = "mysql:host={$MYSQL_HOST};port={$MYSQL_PORT};dbname={$MYSQL_DB};charset=utf8mb4";
    $pdo = new PDO($dsn, $MYSQL_USER, $MYSQL_PASS, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
  } else {
    $baseDir = dirname(__DIR__);
    $dataDir = $baseDir . DIRECTORY_SEPARATOR . 'data';
    
    if (!is_dir($dataDir)) {
        @mkdir($dataDir, 0755, true);
    }
    
    $dbPath = $dataDir . DIRECTORY_SEPARATOR . 'app.sqlite';
    $pdo = new PDO('sqlite:' . $dbPath, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
    $pdo->exec("PRAGMA foreign_keys = ON;");
    
    if (file_exists($dbPath)) {
        @chmod($dbPath, 0600);
    }
  }
} catch (Exception $e) {
  ob_clean();
  http_response_code(500);
  echo json_encode(['error' => 'db_connect_failed', 'message' => $e->getMessage()]);
  exit;
}

// Criação de tabelas (compatível SQLite/MySQL)
$users = "CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT, email TEXT UNIQUE, password_hash TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)";
$projects = "CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  owner_id INTEGER NOT NULL, name TEXT NOT NULL, code TEXT,
  start_date TEXT, end_date TEXT, status TEXT DEFAULT 'PLANNED',
  task_seq INTEGER DEFAULT 0, wo_seq INTEGER DEFAULT 0,
  calendar_type TEXT DEFAULT 'standard',
  hours_per_day INTEGER DEFAULT 8,
  days_per_week INTEGER DEFAULT 5,
  consider_holidays INTEGER DEFAULT 1,
  holidays_json TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)";
$tasks = "CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL, seq INTEGER NOT NULL,
  name TEXT NOT NULL, start TEXT, end TEXT, duration INTEGER,
  durationHours REAL DEFAULT 0,
  percent INTEGER DEFAULT 0, rels_json TEXT, anchor TEXT,
  cost_est REAL DEFAULT 0, cost_act REAL DEFAULT 0,
  diff INTEGER DEFAULT 1, weight_mode TEXT DEFAULT 'time',
  critical INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT, progress_update_date TEXT,
  actual_start_date TEXT, actual_end_date TEXT
)";
$uniq_task_seq = "CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_project_seq ON tasks(project_id, seq)";
$workorders = "CREATE TABLE IF NOT EXISTS workorders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL, seq INTEGER NOT NULL,
  title TEXT NOT NULL, description TEXT, priority TEXT, status TEXT,
  owner TEXT, start TEXT, end TEXT, task_seq_ref INTEGER,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT
)";
$uniq_wo_seq = "CREATE UNIQUE INDEX IF NOT EXISTS idx_wo_project_seq ON workorders(project_id, seq)";
$baselines = "CREATE TABLE IF NOT EXISTS baselines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL, name TEXT NOT NULL, date TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
)";
$task_baselines = "CREATE TABLE IF NOT EXISTS task_baselines (
  task_id INTEGER NOT NULL, baseline_id INTEGER NOT NULL,
  start TEXT, end TEXT, duration INTEGER, weight REAL,
  PRIMARY KEY(task_id, baseline_id)
)";

// Permissões por projeto
$project_members = "CREATE TABLE IF NOT EXISTS project_members (
  project_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  role TEXT NOT NULL, /* admin, collaborator, viewer */
  PRIMARY KEY(project_id, user_id)
)";

foreach ([$users,$projects,$tasks,$workorders,$baselines,$task_baselines,$project_members] as $sql) {
  try {
    $pdo->exec($sql);
  } catch(Exception $e) {
    // Ignore if table already exists
  }
}
foreach ([$uniq_task_seq,$uniq_wo_seq] as $sql) { 
  try{
    $pdo->exec($sql);
  }catch(Exception $e){
    // Ignore if index already exists
  } 
}

function body_json(){ $raw=file_get_contents('php://input'); $d=json_decode($raw?:'', true); return is_array($d)?$d:[]; }
function require_auth(){ if(!isset($_SESSION['user_id'])){ ob_clean(); http_response_code(401); echo json_encode(['error'=>'unauthorized']); exit; } return intval($_SESSION['user_id']); }
function ok($data){ ob_clean(); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function get_user($pdo,$id){ $s=$pdo->prepare('SELECT id,name,email FROM users WHERE id=?'); $s->execute([$id]); return $s->fetch(PDO::FETCH_ASSOC); }

function can_access_project($pdo, int $pid, int $uid, bool $write=false){
  // owner sempre pode
  $s=$pdo->prepare('SELECT owner_id FROM projects WHERE id=?'); $s->execute([$pid]); $o=$s->fetchColumn();
  if(!$o) return false;
  if(intval($o)===intval($uid)) return true;
  // checa membro
  $s=$pdo->prepare('SELECT role FROM project_members WHERE project_id=? AND user_id=?');
  $s->execute([$pid,$uid]); $role=$s->fetchColumn();
  if(!$role) return false;
  if(!$write) return true; // leitura ok para qualquer membro
  return in_array($role, ['admin','collaborator'], true);
}
