<?php
require __DIR__ . '/_bootstrap.php';
$uid = require_auth();
$method = $_SERVER['REQUEST_METHOD'];

if($method==='GET'){
  $project_id = intval($_GET['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,false)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $s=$pdo->prepare('SELECT * FROM baselines WHERE project_id=? ORDER BY id ASC'); $s->execute([$project_id]);
  ok(['baselines'=>$s->fetchAll(PDO::FETCH_ASSOC)]);
}

$d = body_json();
if($method==='POST'){
  $project_id = intval($d['project_id'] ?? 0);
  if(!can_access_project($pdo,$project_id,$uid,true)){ http_response_code(403); echo json_encode(['error'=>'forbidden']); exit; }
  $name = $d['name'] ?? 'Baseline';
  $date = $d['date'] ?? date('Y-m-d');
  $s=$pdo->prepare('INSERT INTO baselines(project_id,name,date) VALUES(?,?,?)'); $s->execute([$project_id,$name,$date]);
  $bid = intval($pdo->lastInsertId());
  $s=$pdo->prepare('SELECT id,duration,start,end FROM tasks WHERE project_id=?'); $s->execute([$project_id]);
  $ins=$pdo->prepare('INSERT INTO task_baselines(task_id,baseline_id,start,end,duration,weight) VALUES(?,?,?,?,?,?)');
  foreach($s->fetchAll(PDO::FETCH_ASSOC) as $t){
    $w = max(1, intval($t['duration'] ?? 1));
    $ins->execute([$t['id'],$bid,$t['start'],$t['end'],$t['duration'] ?? 1,$w]);
  }
  ok(['id'=>$bid]);
}
