<?php
error_reporting(0);
ini_set('display_errors', '0');
ob_start();

require __DIR__ . '/_bootstrap.php';

ob_clean();

$rawInput = file_get_contents('php://input');
$d = json_decode($rawInput, true);

if (!is_array($d)) {
    $d = $_POST;
}

$email = strtolower(trim($d['email'] ?? ''));
$pass  = strval($d['password'] ?? '');

if (!$email || !$pass) { http_response_code(400); ok(['error'=>'missing_fields']); }

$s = $pdo->prepare('SELECT id,name,email,password_hash FROM users WHERE email=? LIMIT 1');
$s->execute([$email]);
$u = $s->fetch();

if (!$u || !password_verify($pass, $u['password_hash'])) {
  http_response_code(401); ok(['error'=>'invalid_credentials']);
}

$_SESSION['user_id'] = intval($u['id']);
ok(['user'=>get_user($pdo,$_SESSION['user_id'])]);
