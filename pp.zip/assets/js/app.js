import { Chart } from "@/components/ui/chart"
// Simple selectors
const $ = (s) => document.querySelector(s)
const $$ = (s) => document.querySelectorAll(s)

let hasUnsavedChanges = false

// Data storage
const Storage = {
  get() {
    const data = localStorage.getItem("ppData")
    return data
      ? JSON.parse(data)
      : {
          projects: [],
          tasks: [],
          workorders: [],
          baselines: [],
          taskBaselines: [],
          materials: [],
          taskMaterials: [],
          assets: [],
          assetLogs: [],
        }
  },
  set(data) {
    localStorage.setItem("ppData", JSON.stringify(data))
    hasUnsavedChanges = true
  },
  clear() {
    localStorage.removeItem("ppData")
    hasUnsavedChanges = false
  },
}

// Projects
const Projects = {
  getAll() {
    return Storage.get().projects
  },
  getById(id) {
    return this.getAll().find((p) => p.id === id)
  },
  create(project) {
    const data = Storage.get()
    const newProject = {
      id: Date.now(),
      name: project.name || "",
      code: project.code || "",
      startDate: project.startDate || "",
      endDate: project.endDate || "",
      duration: project.duration || 0, // Duration added
      status: project.status || "PLANNED",
      taskSeq: 0, // Sequential task counter starting from 0
      woSeq: 0,
      customColumns: [], // Add customColumns field
      createdAt: new Date().toISOString(),
      // Added calendar settings
      calendarType: project.calendarType || "standard",
      hoursPerDay: project.hoursPerDay || 8,
      daysPerWeek: project.daysPerWeek || 5,
      considerHolidays: project.considerHolidays || 0,
      holidaysJson: project.holidaysJson || null,
    }
    data.projects.push(newProject)
    Storage.set(data)
    return newProject
  },
  update(id, updates) {
    const data = Storage.get()
    const index = data.projects.findIndex((p) => p.id === id)
    if (index !== -1) {
      data.projects[index] = { ...data.projects[index], ...updates }
      Storage.set(data)
      return data.projects[index]
    }
    return null
  },
  delete(id) {
    const data = Storage.get()
    data.projects = data.projects.filter((p) => p.id !== id)
    data.tasks = data.tasks.filter((t) => t.projectId !== id)
    data.workorders = data.workorders.filter((w) => w.projectId !== id)
    data.baselines = data.baselines.filter((b) => b.projectId !== id)
    // New: Filter out related data from new modules
    if (data.materials) {
      data.materials = data.materials.filter((m) => m.projectId !== id)
    }
    if (data.assets) {
      data.assets = data.assets.filter((a) => a.projectId !== id)
    }
    Storage.set(data)
  },
}

// WBS calculation function
function calculateWBS(tasks) {
  console.log("[v0] calculateWBS called with", tasks.length, "tasks")

  const rootTasks = tasks.filter((t) => !t.parentId).sort((a, b) => a.id - b.id)
  console.log("[v0] Found", rootTasks.length, "root tasks")

  const wbsMap = {}
  let rootCounter = 1

  function assignWBS(task, parentWBS = "") {
    const siblings = tasks.filter((t) => t.parentId === task.parentId).sort((a, b) => a.id - b.id)
    const index = siblings.findIndex((t) => t.id === task.id) + 1

    const wbs = parentWBS ? `${parentWBS}.${index}` : `${rootCounter}`
    wbsMap[task.id] = wbs

    console.log("[v0] Assigned WBS", wbs, "to task", task.id, "name:", task.name)

    if (!parentWBS) {
      rootCounter++
    }

    const children = tasks.filter((t) => t.parentId === task.id).sort((a, b) => a.id - b.id)
    console.log("[v0] Task", task.id, "has", children.length, "children")
    children.forEach((child) => assignWBS(child, wbs))
  }

  rootTasks.forEach((task) => assignWBS(task))

  console.log("[v0] WBS Map:", wbsMap)
  return wbsMap
}

// Tasks management
const Tasks = {
  getAll() {
    return Storage.get().tasks
  },
  getByProject(projectId) {
    return this.getAll().filter((t) => t.projectId === projectId)
  },
  getById(id) {
    return this.getAll().find((t) => t.id === id)
  },
  create(task) {
    console.log("[v0] Creating task:", task)
    const data = Storage.get()
    const projectIndex = data.projects.findIndex((p) => p.id === task.projectId)
    if (projectIndex === -1) {
      console.log("[v0] Project not found!")
      return null
    }

    const newTaskId = (data.projects[projectIndex].taskSeq || 0) + 1
    data.projects[projectIndex].taskSeq = newTaskId
    console.log("[v0] New task ID:", newTaskId, "Parent ID:", task.parentId)

    const newTask = {
      id: Date.now(),
      taskId: newTaskId,
      projectId: task.projectId,
      wbs: task.wbs || `${newTaskId}`,
      name: task.name || "",
      type: task.type || "task",
      parentId: task.parentId || null,
      group: task.group || "",
      category: task.category || "",
      criticality: task.criticality || "MEDIUM",
      startDate: task.startDate || "",
      startTime: task.startTime || "08:00",
      endDate: task.endDate || "",
      actualStartDate: task.actualStartDate || "", // CHANGED: Use direct property
      actualEndDate: task.actualEndDate || "", // CHANGED: Use direct property
      duration: task.duration || 0,
      durationHours: task.durationHours || 0,
      progress: task.progress || 0,
      progressUpdateDate: task.progressUpdateDate || "", // CHANGED: Use direct property
      predecessors: task.predecessors || "",
      estimatedCost: task.estimatedCost || 0,
      actualCost: task.actualCost || 0,
      weight: task.weight !== undefined ? task.weight : task.type === "milestone" ? 0 : 1, // Ensure weight is set correctly
      assignee: task.assignee || "",
      notes: task.notes || "",
      rowColor: task.rowColor || "",
      customFields: task.customFields || {},
      createdAt: new Date().toISOString(),
    }

    data.tasks.push(newTask)
    console.log("[v0] Task added to data.tasks, total tasks:", data.tasks.length)

    const projectTasks = data.tasks.filter((t) => t.projectId === task.projectId)
    console.log("[v0] Project has", projectTasks.length, "tasks total")
    const wbsMap = calculateWBS(projectTasks)
    projectTasks.forEach((t) => {
      const oldWBS = t.wbs
      t.wbs = wbsMap[t.id] || t.wbs
      if (oldWBS !== t.wbs) {
        console.log("[v0] Updated task", t.id, "WBS from", oldWBS, "to", t.wbs)
      }
    })

    Storage.set(data)
    console.log("[v0] Data saved to storage")

    this.applyPredecessorConstraints(newTask.id)

    if (newTask.parentId) {
      console.log("[v0] Task has parent, calculating parent values")
      this.calculateParentValues(newTask.projectId)
    }

    return newTask
  },

  applyPredecessorConstraints(taskId) {
    const task = this.getById(taskId)
    if (!task || !task.predecessors) return

    const data = Storage.get()
    const predecessorList = task.predecessors
      .split(",")
      .map((p) => p.trim())
      .filter(Boolean)

    let latestEndDate = null

    predecessorList.forEach((predStr) => {
      // Parse predecessor format: "1FS+2" or "2SS" or "3FF-1"
      const match = predStr.match(/^(\d+)(FS|SS|FF|SF)?([+-]\d+)?$/)
      if (!match) return

      const predTaskId = Number.parseInt(match[1])
      const relationType = match[2] || "FS" // Default to Finish-to-Start
      const lag = Number.parseInt(match[3] || "0")

      const predTask = this.getAll().find((t) => t.taskId === predTaskId && t.projectId === task.projectId)
      if (!predTask || !predTask.endDate) return

      let constraintDate
      if (relationType === "FS") {
        // Finish-to-Start: task starts after predecessor finishes
        constraintDate = DateUtils.addDays(predTask.endDate, lag)
      } else if (relationType === "SS") {
        // Start-to-Start: task starts when predecessor starts
        constraintDate = DateUtils.addDays(predTask.startDate, lag)
      } else if (relationType === "FF") {
        // Finish-to-Finish: task finishes when predecessor finishes
        const taskDuration = task.duration || 0
        constraintDate = DateUtils.subtractDays(DateUtils.addDays(predTask.endDate, lag), taskDuration)
      }

      if (constraintDate && (!latestEndDate || new Date(constraintDate) > new Date(latestEndDate))) {
        latestEndDate = constraintDate
      }
    })

    if (latestEndDate && (!task.startDate || new Date(latestEndDate) > new Date(task.startDate))) {
      const updates = { startDate: latestEndDate }
      if (task.duration) {
        updates.endDate = DateUtils.addDays(latestEndDate, task.duration)
      }
      this.update(taskId, updates)
    }
  },

  isTaskDelayed(taskId) {
    const task = this.getById(taskId)
    if (!task || !task.endDate) return false

    const project = Projects.getById(task.projectId)
    if (!project || !project.endDate) return false

    return new Date(task.endDate) > new Date(project.endDate)
  },

  calculateParentValues(projectId) {
    // Changed to accept projectId for easier WBS recalculation
    const tasks = Tasks.getByProject(projectId)
    const wbsMap = calculateWBS(tasks)
    tasks.forEach((t) => {
      t.wbs = wbsMap[t.id] || t.wbs
    })

    // Find all leaf tasks (tasks that have a parent but no children)
    const leafTasks = tasks.filter((t) => {
      const hasParent = t.parentId
      const hasChildren = tasks.some((child) => child.parentId === t.id)
      return hasParent && !hasChildren
    })

    // Track which parents we've already updated to avoid duplicates
    const updatedParents = new Set()

    // Start from leaf tasks and recursively update parents
    leafTasks.forEach((leaf) => {
      if (leaf.parentId && !updatedParents.has(leaf.parentId)) {
        Tasks.calculateParentValuesRecursive(leaf.parentId, updatedParents)
      }
    })
  },

  calculateParentValuesRecursive(parentId, visited = new Set()) {
    if (visited.has(parentId)) return null
    visited.add(parentId)

    const children = Tasks.getByProject(Tasks.getById(parentId)?.projectId || -1).filter((t) => t.parentId === parentId)
    if (children.length === 0) return null

    const parent = Tasks.getById(parentId)
    if (!parent) return null

    // Calculate rollup values
    const startDates = children.map((c) => c.startDate).filter(Boolean)
    const endDates = children.map((c) => c.endDate).filter(Boolean)
    const totalEstimatedCost = children.reduce((sum, c) => sum + (c.estimatedCost || 0), 0)
    const totalActualCost = children.reduce((sum, c) => sum + (c.actualCost || 0), 0)
    const totalWeight = children.reduce((sum, c) => sum + (c.weight || 0), 0)
    const weightedProgress =
      totalWeight > 0 ? children.reduce((sum, c) => sum + (c.progress || 0) * (c.weight || 0), 0) / totalWeight : 0

    const updates = {
      startDate: startDates.length > 0 ? startDates.sort()[0] : parent.startDate,
      endDate: endDates.length > 0 ? endDates.sort().reverse()[0] : parent.endDate,
      estimatedCost: totalEstimatedCost,
      actualCost: totalActualCost,
      progress: Math.round(weightedProgress),
    }

    // Calculate duration if both dates are exist
    if (updates.startDate && updates.endDate) {
      updates.duration = DateUtils.calcDuration(updates.startDate, updates.endDate)
    }

    this.update(parentId, updates, true)

    // Recursively update parent's parent
    if (parent.parentId) {
      this.calculateParentValuesRecursive(parent.parentId, visited)
    }

    return updates
  },

  update(id, updates, skipParentCalc = false) {
    const data = Storage.get()
    const index = data.tasks.findIndex((t) => t.id === id)
    if (index === -1) return false

    data.tasks[index] = { ...data.tasks[index], ...updates }

    if (updates.parentId !== undefined) {
      const projectId = data.tasks[index].projectId
      const projectTasks = data.tasks.filter((t) => t.projectId === projectId)
      const wbsMap = calculateWBS(projectTasks)
      projectTasks.forEach((t) => {
        t.wbs = wbsMap[t.id] || t.wbs
      })
    }

    Storage.set(data)

    if (!skipParentCalc) {
      const projectId = data.tasks[index].projectId
      if (projectId) {
        Tasks.calculateParentValues(projectId)
      }
    }

    if (updates.predecessors !== undefined) {
      this.applyPredecessorConstraints(id)
    }

    return true
  },
  delete(id) {
    console.log("[v0] Tasks.delete called with id:", id)
    const data = Storage.get()
    const deleteRecursive = (taskId) => {
      const children = data.tasks.filter((t) => t.parentId === taskId)
      children.forEach((child) => deleteRecursive(child.id))
      data.tasks = data.tasks.filter((t) => t.id !== taskId)
    }
    const taskToDelete = this.getById(id)
    if (taskToDelete) {
      deleteRecursive(id)
      this.reindexTaskIds(taskToDelete.projectId)
      // Recalculate WBS for the project
      const projectTasks = data.tasks.filter((t) => t.projectId === taskToDelete.projectId)
      const wbsMap = calculateWBS(projectTasks)
      projectTasks.forEach((t) => {
        t.wbs = wbsMap[t.id] || t.wbs
      })
      // Recalculate parent values
      Tasks.calculateParentValues(taskToDelete.projectId)
    }
    Storage.set(data)
    console.log("[v0] Task deletion complete")
  },

  reindexTaskIds(projectId) {
    const data = Storage.get()
    const projectTasks = data.tasks.filter((t) => t.projectId === projectId).sort((a, b) => a.taskId - b.taskId)

    // Create a mapping of old taskId to new taskId
    const taskIdMap = {}
    projectTasks.forEach((task, index) => {
      const oldTaskId = task.taskId
      const newTaskId = index + 1
      taskIdMap[oldTaskId] = newTaskId
      task.taskId = newTaskId
    })

    // Update predecessor references
    projectTasks.forEach((task) => {
      if (task.predecessors) {
        const updatedPredecessors = task.predecessors
          .split(",")
          .map((pred) => {
            const match = pred.trim().match(/^(\d+)(FS|SS|FF|SF)?([+-]\d+)?$/)
            if (!match) return pred

            const oldPredId = Number.parseInt(match[1])
            const newPredId = taskIdMap[oldPredId]
            if (!newPredId) return "" // Predecessor was deleted

            const relationType = match[2] || ""
            const lag = match[3] || ""
            return `${newPredId}${relationType}${lag}`
          })
          .filter(Boolean)
          .join(", ")

        task.predecessors = updatedPredecessors
      }
    })

    // Update project taskSeq
    const projectIndex = data.projects.findIndex((p) => p.id === projectId)
    if (projectIndex !== -1) {
      data.projects[projectIndex].taskSeq = projectTasks.length
    }

    Storage.set(data)
  },

  getTaskLevel(taskId) {
    let level = 0
    let task = this.getById(taskId)
    while (task && task.parentId) {
      level++
      task = this.getById(task.parentId)
    }
    return level
  },
}

// WorkOrders management
const WorkOrders = {
  getAll() {
    return Storage.get().workorders
  },
  getByProject(projectId) {
    return this.getAll().filter((w) => w.projectId === projectId)
  },
  getById(id) {
    return this.getAll().find((w) => w.id === id)
  },
  create(wo) {
    const data = Storage.get()
    const project = Projects.getById(wo.projectId)
    if (!project) return null

    const newWO = {
      id: Date.now(),
      projectId: wo.projectId,
      number: `OS-${project.woSeq + 1}`,
      title: wo.title || "",
      priority: wo.priority || "MEDIUM",
      status: wo.status || "OPEN",
      assignee: wo.assignee || "",
      startDate: wo.startDate || "",
      endDate: wo.endDate || "",
      actualStartDate: wo.actualStartDate || "",
      actualEndDate: wo.actualEndDate || "",
      estimatedHours: wo.estimatedHours || 0,
      actualHours: wo.actualHours || 0,
      progress: wo.progress || 0,
      taskId: wo.taskId || null,
      description: wo.description || "",
      createdAt: new Date().toISOString(),
    }

    data.workorders.push(newWO)
    Projects.update(wo.projectId, { woSeq: project.woSeq + 1 })
    Storage.set(data)
    return newWO
  },
  update(id, updates) {
    const data = Storage.get()
    const index = data.workorders.findIndex((w) => w.id === id)
    if (index !== -1) {
      data.workorders[index] = { ...data.workorders[index], ...updates }
      Storage.set(data)
      return data.workorders[index]
    }
    return null
  },
  delete(id) {
    const data = Storage.get()
    data.workorders = data.workorders.filter((w) => w.id !== id)
    Storage.set(data)
  },
  calculateMetrics(wo) {
    const metrics = {
      scheduleVariance: 0,
      timeVariance: 0,
      isDelayed: false,
      isOnTrack: false,
      isCompleted: false,
    }

    if (!wo.startDate || !wo.endDate) return metrics

    const today = new Date()
    const plannedStart = new Date(wo.startDate)
    const plannedEnd = new Date(wo.endDate)
    const actualStart = wo.actualStartDate ? new Date(wo.actualStartDate) : null
    const actualEnd = wo.actualEndDate ? new Date(wo.actualEndDate) : null

    // Calculate schedule variance (days)
    if (actualStart) {
      metrics.scheduleVariance = Math.ceil((actualStart - plannedStart) / (1000 * 60 * 60 * 24))
    }

    // Calculate time variance (hours)
    if (wo.estimatedHours > 0) {
      metrics.timeVariance = wo.actualHours - wo.estimatedHours
    }

    // Determine status
    metrics.isCompleted = wo.progress >= 100 || wo.status === "COMPLETED"

    if (metrics.isCompleted) {
      if (actualEnd && actualEnd > plannedEnd) {
        metrics.isDelayed = true
      }
    } else {
      // In progress or not started
      if (today > plannedEnd) {
        metrics.isDelayed = true
      } else if (today >= plannedStart && today <= plannedEnd) {
        const totalDuration = (plannedEnd - plannedStart) / (1000 * 60 * 60 * 24)
        const elapsedDuration = (today - plannedStart) / (1000 * 60 * 60 * 24)
        const expectedProgress = (elapsedDuration / totalDuration) * 100

        if (wo.progress >= expectedProgress - 10) {
          metrics.isOnTrack = true
        } else {
          metrics.isDelayed = true
        }
      }
    }

    return metrics
  },
}

function autoPopulateWOFromTask(taskId, projectId) {
  if (!taskId) return {}

  const task = Tasks.getById(Number.parseInt(taskId))
  if (!task) return {}

  // Calculate estimated hours from task duration (days * 8 hours)
  const estimatedHours = (task.duration || 0) * 8

  return {
    title: task.name || "",
    startDate: task.startDate || "",
    endDate: task.endDate || "",
    actualStartDate: task.actualStartDate || "",
    actualEndDate: task.actualEndDate || "",
    estimatedHours: estimatedHours,
    progress: task.progress || 0,
    assignee: task.responsible || "",
    description: task.notes || "",
  }
}

const WOAutoCalc = {
  // Auto-calculate estimated hours from date range
  calcEstimatedHours(startDate, endDate) {
    if (!startDate || !endDate) return 0
    const days = DateUtils.calcDuration(startDate, endDate)
    return days * 8 // 8 hours per day
  },

  // Auto-calculate progress from actual vs estimated hours
  calcProgressFromHours(actualHours, estimatedHours) {
    if (!estimatedHours || estimatedHours === 0) return 0
    const progress = Math.round((actualHours / estimatedHours) * 100)
    return Math.min(progress, 100)
  },

  // Auto-calculate remaining hours
  calcRemainingHours(estimatedHours, actualHours) {
    return Math.max(0, estimatedHours - actualHours)
  },

  // Auto-calculate estimated completion date based on progress
  calcEstimatedCompletion(startDate, endDate, progress) {
    if (!startDate || !endDate || progress >= 100) return endDate

    const start = new Date(startDate)
    const end = new Date(endDate)
    const totalDuration = (end - start) / (1000 * 60 * 60 * 24)
    const elapsedDuration = (totalDuration * progress) / 100

    const today = new Date()
    const actualElapsed = (today - start) / (1000 * 60 * 60 * 24)

    if (actualElapsed <= 0) return endDate

    const velocity = progress / actualElapsed
    const remainingProgress = 100 - progress
    const estimatedRemainingDays = remainingProgress / velocity

    const estimatedEnd = new Date(today)
    estimatedEnd.setDate(estimatedEnd.getDate() + estimatedRemainingDays)

    return estimatedEnd.toISOString().split("T")[0]
  },
}

// Date calculation utilities
const DateUtils = {
  // Calculate business days between two dates
  calcDuration(startDate, endDate) {
    if (!startDate || !endDate) return 0
    const start = new Date(startDate)
    const end = new Date(endDate)
    const diffTime = Math.abs(end - start)
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  },

  // Add days to a date
  addDays(dateStr, days) {
    if (!dateStr || !days) return ""
    const date = new Date(dateStr)
    date.setDate(date.getDate() + Number.parseInt(days))
    return date.toISOString().split("T")[0]
  },

  // Subtract days from a date
  subtractDays(dateStr, days) {
    if (!dateStr || !days) return ""
    const date = new Date(dateStr)
    date.setDate(date.getDate() - Number.parseInt(days))
    return date.toISOString().split("T")[0]
  },
}

const ImportExport = {
  export(filename, author, company) {
    const data = Storage.get()
    const exportData = {
      ...data,
      metadata: {
        filename: filename || "planejar-programar",
        author: author || "",
        company: company || "",
        exportDate: new Date().toISOString(),
        version: "1.0",
      },
    }
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${filename || "planejar-programar"}-${new Date().toISOString().split("T")[0]}.pp`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    hasUnsavedChanges = false
  },
  import(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result)
          if (!data.projects || !Array.isArray(data.projects)) {
            throw new Error("Formato de arquivo inválido")
          }
          // Remove metadata before storing
          const { metadata, ...storageData } = data
          Storage.set(storageData)
          hasUnsavedChanges = false
          resolve(data)
        } catch (error) {
          reject(error)
        }
      }
      reader.onerror = () => reject(new Error("Erro ao ler arquivo"))
      reader.readAsText(file)
    })
  },
}

const CustomColumns = {
  getColumns(projectId) {
    const data = Storage.get()
    const project = Projects.getById(projectId)
    return project?.customColumns || []
  },

  addColumn(projectId, column) {
    const project = Projects.getById(projectId)
    if (!project) return

    const customColumns = project.customColumns || []
    customColumns.push({
      id: Date.now(),
      label: column.label,
      type: column.type || "text",
      width: column.width || "120px",
    })

    Projects.update(projectId, { customColumns })
  },

  removeColumn(projectId, columnId) {
    const project = Projects.getById(projectId)
    if (!project) return

    const customColumns = (project.customColumns || []).filter((c) => c.id !== columnId)
    Projects.update(projectId, { customColumns })
  },
}

// Baselines management
const Baselines = {
  getAll() {
    return Storage.get().baselines
  },
  getByProject(projectId) {
    return this.getAll().filter((b) => b.projectId === projectId)
  },
  getById(id) {
    return this.getAll().find((b) => b.id === id)
  },
  create(projectId, name) {
    const data = Storage.get()
    const project = Projects.getById(projectId)
    if (!project) return null

    const tasks = Tasks.getByProject(projectId)

    const newBaseline = {
      id: Date.now(),
      projectId: projectId,
      name: name || `Baseline ${new Date().toLocaleDateString()}`,
      createdAt: new Date().toISOString(),
      projectSnapshot: { ...project },
      tasksSnapshot: tasks.map((t) => ({ ...t })),
    }

    data.baselines.push(newBaseline)
    Storage.set(data)
    return newBaseline
  },
  delete(id) {
    const data = Storage.get()
    data.baselines = data.baselines.filter((b) => b.id !== id)
    Storage.set(data)
  },
}

// Project progress calculation
const ProjectMetrics = {
  calculate(projectId, baselineId = null) {
    const project = Projects.getById(projectId)
    const tasks = Tasks.getByProject(projectId)

    if (!project || tasks.length === 0) return null

    // Calculate current metrics
    const totalWeight = tasks.reduce((sum, t) => sum + (t.weight || 0), 0)
    const weightedProgress =
      totalWeight > 0 ? tasks.reduce((sum, t) => sum + (t.progress || 0) * (t.weight || 0), 0) / totalWeight : 0

    const totalPlannedCost = tasks.reduce((sum, t) => sum + (t.estimatedCost || 0), 0)
    const totalActualCost = tasks.reduce((sum, t) => sum + (t.actualCost || 0), 0)
    const earnedValue = totalPlannedCost * (weightedProgress / 100)

    const totalPlannedHours = tasks.reduce((sum, t) => sum + (t.durationHours || 0), 0)
    const completedHours = tasks.reduce((sum, t) => sum + ((t.durationHours || 0) * (t.progress || 0)) / 100, 0)

    // Calculate schedule metrics
    const today = new Date()
    const projectStart = project.startDate ? new Date(project.startDate) : today
    const projectEnd = project.endDate ? new Date(project.endDate) : today
    const totalDuration = (projectEnd - projectStart) / (1000 * 60 * 60 * 24)
    const elapsedDuration = (today - projectStart) / (1000 * 60 * 60 * 24)
    const plannedProgress = totalDuration > 0 ? Math.min(100, (elapsedDuration / totalDuration) * 100) : 0

    // Calculate earned value metrics
    const CPI = totalActualCost > 0 ? earnedValue / totalActualCost : 1
    const SPI = plannedProgress > 0 ? weightedProgress / plannedProgress : 1
    const costVariance = earnedValue - totalActualCost
    const scheduleVariance = weightedProgress - plannedProgress

    // Calculate completion estimates
    const estimateAtCompletion = CPI > 0 ? totalPlannedCost / CPI : totalPlannedCost
    const estimateToComplete = estimateAtCompletion - totalActualCost
    const varianceAtCompletion = totalPlannedCost - estimateAtCompletion

    return {
      progress: Math.round(weightedProgress),
      plannedProgress: Math.round(plannedProgress),
      totalPlannedCost,
      totalActualCost,
      earnedValue,
      totalPlannedHours,
      completedHours,
      CPI: CPI.toFixed(2),
      SPI: SPI.toFixed(2),
      costVariance: costVariance.toFixed(2),
      scheduleVariance: scheduleVariance.toFixed(2),
      estimateAtCompletion: estimateAtCompletion.toFixed(2),
      estimateToComplete: estimateToComplete.toFixed(2),
      varianceAtCompletion: varianceAtCompletion.toFixed(2),
      daysElapsed: Math.round(elapsedDuration),
      daysTotal: Math.round(totalDuration),
      daysRemaining: Math.round(totalDuration - elapsedDuration),
    }
  },

  generateSCurveData(projectId, baselineId = null) {
    const project = Projects.getById(projectId)
    const tasks = Tasks.getByProject(projectId)

    if (!project || !project.startDate || !project.endDate) return null

    const startDate = new Date(project.startDate)
    const endDate = new Date(project.endDate)
    const totalDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24))

    const data = []
    const totalWeight = tasks.reduce((sum, t) => sum + (t.weight || 0), 0)

    for (let day = 0; day <= totalDays; day++) {
      const currentDate = new Date(startDate)
      currentDate.setDate(currentDate.getDate() + day)

      let plannedCost = 0
      let actualCost = 0
      let plannedHours = 0
      let actualHours = 0
      let plannedProgress = 0
      let actualProgress = 0
      let plannedWeightedProgress = 0
      let actualWeightedProgress = 0

      tasks.forEach((task) => {
        const taskStart = task.startDate ? new Date(task.startDate) : null
        const taskEnd = task.endDate ? new Date(task.endDate) : null
        const taskWeight = task.weight || 0

        if (taskStart && taskEnd && currentDate >= taskStart) {
          const taskDuration = (taskEnd - taskStart) / (1000 * 60 * 60 * 24)
          const elapsedDays = Math.min((currentDate - taskStart) / (1000 * 60 * 60 * 24), taskDuration)
          const plannedPercent = taskDuration > 0 ? Math.min(100, (elapsedDays / taskDuration) * 100) : 0

          // Planned values (linear distribution)
          plannedCost += (task.estimatedCost || 0) * (plannedPercent / 100)
          plannedHours += (task.durationHours || 0) * (plannedPercent / 100)
          plannedProgress += plannedPercent
          plannedWeightedProgress += taskWeight * (plannedPercent / 100)

          // Actual values (based on reported progress)
          if (currentDate <= new Date()) {
            actualCost += task.actualCost || 0
            actualHours += (task.durationHours || 0) * ((task.progress || 0) / 100)
            actualProgress += task.progress || 0
            actualWeightedProgress += taskWeight * ((task.progress || 0) / 100)
          }
        }
      })

      data.push({
        day,
        date: currentDate.toISOString().split("T")[0],
        plannedCost,
        actualCost,
        plannedHours,
        actualHours,
        plannedProgress: tasks.length > 0 ? plannedProgress / tasks.length : 0,
        actualProgress: tasks.length > 0 ? actualProgress / tasks.length : 0,
        weightedProgress: totalWeight > 0 ? (actualWeightedProgress / totalWeight) * 100 : 0,
      })
    }

    return data
  },
}

// Navigation - simplified
function showSection(sectionId) {
  // Hide all sections
  $$(".section").forEach((s) => s.classList.add("hidden"))

  // Show target section
  const target = $(sectionId)
  if (target) {
    target.classList.remove("hidden")
  }

  // Update active button
  $$(".menu button").forEach((b) => b.classList.remove("active"))
}

// Load projects table
function loadProjects() {
  const projects = Projects.getAll()
  const tbody = $("#projectsTable tbody")
  if (!tbody) return

  tbody.innerHTML = projects
    .map(
      (p) => `
    <tr>
      <td>${p.name}</td>
      <td>${p.code}</td>
      <td>${p.startDate || "-"} até ${p.endDate || "-"}</td>
      <td><span class="badge">${p.status}</span></td>
      <td>
        <button onclick="editProject(${p.id})">Editar</button>
        <button onclick="deleteProject(${p.id})" class="danger">Excluir</button>
      </td>
    </tr>
  `,
    )
    .join("")
}

// Load project selects
function loadProjectSelects() {
  const projects = Projects.getAll()
  const html =
    '<option value="">Selecione um projeto</option>' +
    projects.map((p) => `<option value="${p.id}">${p.name}</option>`).join("")

  const selects = [
    "#selProjectSchedule",
    "#selProjectWO",
    "#selProjectS",
    "#selProjectReports",
    "#selProjectMaterials",
    "#selProjectAssets",
  ]
  selects.forEach((sel) => {
    const el = $(sel)
    if (el) el.innerHTML = html
  })
}

function showProjectDialog(project = null) {
  const dialog = $("#projectDialog")
  const isEdit = !!project

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">${isEdit ? "Editar" : "Novo"} Projeto</h2>
    <form id="projectForm">
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <label>
          Nome do Projeto *
          <input type="text" id="projectName" value="${project?.name || ""}" required>
        </label>
        <label>
          Código
          <input type="text" id="projectCode" value="${project?.code || ""}">
        </label>
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
          <label>
            Data de Início
            <input type="date" id="projectStartDate" value="${project?.startDate || ""}">
          </label>
          <label>
            Data de Término
            <input type="date" id="projectEndDate" value="${project?.endDate || ""}">
          </label>
          <label>
            Duração (dias)
            <input type="number" id="projectDuration" min="0" value="${project?.startDate && project?.endDate ? DateUtils.calcDuration(project.startDate, project.endDate) : ""}">
          </label>
        </div>
        
        <fieldset style="border: 1px solid #ddd; padding: 12px; border-radius: 4px;">
          <legend style="font-weight: bold;">Configurações de Calendário</legend>
          
          <label>
            Tipo de Calendário
            <select id="projectCalendarType" onchange="updateCalendarFields()">
              <option value="standard" ${!project || project.calendarType === "standard" ? "selected" : ""}>Padrão (8h/dia, 5 dias/semana)</option>
              <option value="24x7" ${project?.calendarType === "24x7" ? "selected" : ""}>24 horas (24h/dia, 7 dias/semana)</option>
              <option value="custom" ${project?.calendarType === "custom" ? "selected" : ""}>Personalizado</option>
            </select>
          </label>
          
          <div id="customCalendarFields" style="display: ${project?.calendarType === "custom" ? "grid" : "none"}; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px;">
            <label>
              Horas por Dia
              <input type="number" id="projectHoursPerDay" min="1" max="24" value="${project?.hoursPerDay || 8}">
            </label>
            <label>
              Dias por Semana
              <input type="number" id="projectDaysPerWeek" min="1" max="7" value="${project?.daysPerWeek || 5}">
            </label>
          </div>
          
          <label style="margin-top: 12px; display: flex; align-items: center; gap: 8px;">
            <input type="checkbox" id="projectConsiderHolidays" ${!project || project.considerHolidays ? "checked" : ""}>
            Considerar Feriados nos Cálculos
          </label>
          
          <div id="holidaysSection" style="margin-top: 12px; ${!project || project.considerHolidays ? "" : "display: none;"}">
            <label>
              Feriados (um por linha, formato: AAAA-MM-DD Nome)
              <textarea id="projectHolidays" rows="4" placeholder="2024-01-01 Ano Novo&#10;2024-12-25 Natal">${
                project?.holidaysJson
                  ? JSON.parse(project.holidaysJson)
                      .map((h) => `${h.date} ${h.name}`)
                      .join("\n")
                  : ""
              }</textarea>
            </label>
            <button type="button" onclick="loadNationalHolidays()" style="margin-top: 8px;">Carregar Feriados Nacionais 2024-2025</button>
          </div>
        </fieldset>
        
        <label>
          Status
          <select id="projectStatus">
            <option value="PLANNED" ${project?.status === "PLANNED" ? "selected" : ""}>Planejado</option>
            <option value="ACTIVE" ${project?.status === "ACTIVE" ? "selected" : ""}>Ativo</option>
            <option value="PAUSED" ${project?.status === "PAUSED" ? "selected" : ""}>Pausado</option>
            <option value="COMPLETED" ${project?.status === "COMPLETED" ? "selected" : ""}>Concluído</option>
          </select>
        </label>
      </div>
      <div class="row" style="margin-top: 16px; justify-content: flex-end;">
        <button type="button" onclick="document.getElementById('projectDialog').close()">Cancelar</button>
        <button type="submit">Salvar</button>
      </div>
    </form>
  `

  dialog.classList.remove("hidden")

  window.updateCalendarFields = () => {
    const calendarType = $("#projectCalendarType").value
    const customFields = $("#customCalendarFields")
    const hoursPerDay = $("#projectHoursPerDay")
    const daysPerWeek = $("#projectDaysPerWeek")

    if (calendarType === "standard") {
      customFields.style.display = "none"
      hoursPerDay.value = 8
      daysPerWeek.value = 5
    } else if (calendarType === "24x7") {
      customFields.style.display = "none"
      hoursPerDay.value = 24
      daysPerWeek.value = 7
    } else {
      customFields.style.display = "grid"
    }
  }

  window.loadNationalHolidays = () => {
    const holidays = [
      "2024-01-01 Ano Novo",
      "2024-02-13 Carnaval",
      "2024-03-29 Sexta-feira Santa",
      "2024-04-21 Tiradentes",
      "2024-05-01 Dia do Trabalho",
      "2024-05-30 Corpus Christi",
      "2024-09-07 Independência do Brasil",
      "2024-10-12 Nossa Senhora Aparecida",
      "2024-11-02 Finados",
      "2024-11-15 Proclamação da República",
      "2024-11-20 Consciência Negra",
      "2024-12-25 Natal",
      "2025-01-01 Ano Novo",
      "2025-03-04 Carnaval",
      "2025-04-18 Sexta-feira Santa",
      "2025-04-21 Tiradentes",
      "2025-05-01 Dia do Trabalho",
      "2025-06-19 Corpus Christi",
      "2025-09-07 Independência do Brasil",
      "2025-10-12 Nossa Senhora Aparecida",
      "2025-11-02 Finados",
      "2025-11-15 Proclamação da República",
      "2025-11-20 Consciência Negra",
      "2025-12-25 Natal",
    ]
    $("#projectHolidays").value = holidays.join("\n")
  }

  $("#projectConsiderHolidays").addEventListener("change", (e) => {
    $("#holidaysSection").style.display = e.target.checked ? "block" : "none"
  })

  const startDateInput = $("#projectStartDate")
  const endDateInput = $("#projectEndDate")
  const durationInput = $("#projectDuration")

  startDateInput.addEventListener("change", () => {
    const start = startDateInput.value
    const end = endDateInput.value
    const duration = durationInput.value

    if (start && end) {
      // Calculate duration from dates
      durationInput.value = DateUtils.calcDuration(start, end)
    } else if (start && duration) {
      // Calculate end date from start + duration
      endDateInput.value = DateUtils.addDays(start, duration)
    }
  })

  endDateInput.addEventListener("change", () => {
    const start = startDateInput.value
    const end = endDateInput.value

    if (start && end) {
      // Calculate duration from dates
      durationInput.value = DateUtils.calcDuration(start, end)
    }
  })

  durationInput.addEventListener("input", () => {
    const start = startDateInput.value
    const duration = durationInput.value

    if (start && duration) {
      // Calculate end date from start + duration
      endDateInput.value = DateUtils.addDays(start, duration)
    }
  })

  const form = $("#projectForm")
  form.onsubmit = (e) => {
    e.preventDefault()

    const calendarType = $("#projectCalendarType").value
    let hoursPerDay = 8
    let daysPerWeek = 5

    if (calendarType === "24x7") {
      hoursPerDay = 24
      daysPerWeek = 7
    } else if (calendarType === "custom") {
      hoursPerDay = Number.parseInt($("#projectHoursPerDay").value) || 8
      daysPerWeek = Number.parseInt($("#projectDaysPerWeek").value) || 5
    }

    const holidaysText = $("#projectHolidays").value.trim()
    let holidaysJson = null
    if ($("#projectConsiderHolidays").checked && holidaysText) {
      const holidays = holidaysText
        .split("\n")
        .map((line) => {
          const parts = line.trim().split(" ")
          return {
            date: parts[0],
            name: parts.slice(1).join(" "),
          }
        })
        .filter((h) => h.date && h.name)
      holidaysJson = JSON.stringify(holidays)
    }

    const data = {
      name: $("#projectName").value,
      code: $("#projectCode").value,
      startDate: $("#projectStartDate").value || null,
      endDate: $("#projectEndDate").value || null,
      status: $("#projectStatus").value,
      calendarType: calendarType,
      hoursPerDay: hoursPerDay,
      daysPerWeek: daysPerWeek,
      considerHolidays: $("#projectConsiderHolidays").checked ? 1 : 0,
      holidaysJson: holidaysJson,
    }

    if (isEdit) {
      data.id = project.id
      Projects.update(data)
    } else {
      Projects.create(data)
    }

    dialog.close()
    loadProjects()
    loadProjectSelects()
    hasUnsavedChanges = true
  }

  dialog.showModal()
}

// Global helper functions for task dialog
window.setTodayDateTime = (inputId) => {
  const input = document.getElementById(inputId)
  if (!input) return

  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, "0")
  const day = String(now.getDate()).padStart(2, "0")
  const hours = String(now.getHours()).padStart(2, "0")
  const minutes = String(now.getMinutes()).padStart(2, "0")

  input.value = `${year}-${month}-${day}T${hours}:${minutes}`
}

window.setQuickProgress = (value) => {
  const progressInput = document.getElementById("taskProgress")
  if (!progressInput) return

  const previousValue = Number.parseInt(progressInput.getAttribute("data-previous-value")) || 0
  progressInput.value = value

  // Update progress date
  window.updateProgressDate()

  // Auto-fill actual dates based on progress
  const actualStartInput = document.getElementById("taskActualStartDate")
  const actualEndInput = document.getElementById("taskActualEndDate")

  // If going from 0% to any value > 0%, fill actual start date
  if (previousValue === 0 && value > 0 && actualStartInput && !actualStartInput.value) {
    window.setTodayDateTime("taskActualStartDate")
  }

  // If reaching 100%, fill actual end date
  if (value === 100 && actualEndInput && !actualEndInput.value) {
    window.setTodayDateTime("taskActualEndDate")
  }

  // Update the previous value
  progressInput.setAttribute("data-previous-value", value)
}

window.updateProgressDate = () => {
  const progressInput = document.getElementById("taskProgress")
  const progressUpdateDateInput = document.getElementById("taskProgressUpdateDate")

  if (!progressInput || !progressUpdateDateInput) return

  const currentValue = Number.parseInt(progressInput.value) || 0
  const previousValue = Number.parseInt(progressInput.getAttribute("data-previous-value")) || 0

  // Only update if progress actually changed
  if (currentValue !== previousValue) {
    window.setTodayDateTime("taskProgressUpdateDate")

    // Auto-fill actual dates based on progress
    const actualStartInput = document.getElementById("taskActualStartDate")
    const actualEndInput = document.getElementById("taskActualEndDate")

    // If going from 0% to any value > 0%, fill actual start date
    if (previousValue === 0 && currentValue > 0 && actualStartInput && !actualStartInput.value) {
      window.setTodayDateTime("taskActualStartDate")
    }

    // If reaching 100%, fill actual end date
    if (currentValue === 100 && actualEndInput && !actualEndInput.value) {
      window.setTodayDateTime("taskActualEndDate")
    }

    // Update the previous value
    progressInput.setAttribute("data-previous-value", currentValue)
  }
}

// Fixed task dialog structure and values
function showTaskDialog(projectId, task = null) {
  const dialog = $("#taskDialog")
  const isEdit = !!task

  const data = Storage.get()
  const project = data.projects.find((p) => p.id === projectId)
  if (!project) return

  const allTasks = Tasks.getByProject(projectId).filter((t) => !isEdit || t.id !== task?.id)
  const nextTaskId = (project.taskSeq || 0) + 1

  const defaultWBS = `${nextTaskId}`
  let defaultStartDate = project.startDate || ""
  let defaultEndDate = ""

  if (task?.parentId) {
    const parent = allTasks.find((t) => t.id === task.parentId)
    if (parent) {
      defaultStartDate = parent.startDate || defaultStartDate
      defaultEndDate = parent.endDate || ""
    }
  }

  const buildTaskOption = (t) => {
    const level = Tasks.getTaskLevel(t.id)
    const indent = "  ".repeat(level)
    const wbs = t.wbs || t.taskId
    return `<option value="${t.id}" ${task?.parentId === t.id ? "selected" : ""}>${indent}${wbs} - ${t.name}</option>`
  }

  // Prepare task data for dialog, handling potential null/undefined values
  const taskData = task
    ? {
        id: task.id,
        taskId: task.taskId,
        name: task.name || "",
        type: task.type || "task",
        wbs: task.wbs || defaultWBS,
        parentId: task.parentId || null,
        group: task.group || "",
        category: task.category || "",
        criticality: task.criticality || "MEDIUM",
        startDate: task.startDate || "",
        startTime: task.startTime || "08:00",
        endDate: task.endDate || "",
        actualStartDate: task.actualStartDate || "", // CHANGED: Use direct property
        actualEndDate: task.actualEndDate || "", // CHANGED: Use direct property
        duration: task.duration || 0,
        durationHours: task.durationHours || 0,
        progress: task.progress || 0,
        progressUpdateDate: task.progressUpdateDate || "", // CHANGED: Use direct property
        predecessors: task.predecessors || "",
        estimatedCost: task.estimatedCost || 0,
        actualCost: task.actualCost || 0,
        weight: task.weight !== undefined ? task.weight : task.type === "milestone" ? 0 : 1, // Ensure weight is set correctly
        assignee: task.assignee || "",
        notes: task.notes || "",
        rowColor: task.rowColor || "#ffffff",
      }
    : {
        id: null,
        taskId: nextTaskId,
        name: "",
        type: "task",
        wbs: defaultWBS,
        parentId: null,
        group: "",
        category: "",
        criticality: "MEDIUM",
        startDate: defaultStartDate,
        startTime: "08:00",
        endDate: defaultEndDate,
        actualStartDate: "", // CHANGED: Default to empty
        actualEndDate: "", // CHANGED: Default to empty
        duration: 1,
        durationHours: 8,
        progress: 0,
        progressUpdateDate: "", // CHANGED: Default to empty
        predecessors: "",
        estimatedCost: 0,
        actualCost: 0,
        weight: 1,
        assignee: "",
        notes: "",
        rowColor: "#ffffff",
      }

  // Ensure the dialog element exists, create if not
  if (!dialog) {
    const newDialog = document.createElement("dialog")
    newDialog.id = "taskDialog"
    newDialog.style.maxWidth = "900px"
    newDialog.style.width = "90%"
    newDialog.style.borderRadius = "12px"
    newDialog.style.border = "1px solid #e2e8f0"
    newDialog.style.padding = "0"
    document.body.appendChild(newDialog)
  }

  // Dynamically set dialog content
  const dialogHTML = `
    <div style="padding: 20px; border-bottom: 1px solid #e2e8f0;">
      <h2 style="margin: 0; font-size: 20px;">${task ? "Editar Tarefa" : "Nova Tarefa"}</h2>
    </div>
    <div style="padding: 20px;">
    <form id="taskForm" style="max-height: 70vh; overflow-y: auto;">
      <div style="display: flex; flex-direction: column; gap: 12px;">
        
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 12px;">
          <label>
            ID da Tarefa
            <input type="text" value="${taskData.taskId}" disabled style="background: #f1f5f9; font-weight: 600;">
          </label>
          <label>
            Nome da Tarefa *
            <input type="text" id="taskName" value="${taskData.name}" required>
          </label>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
          <label>
            Tipo
            <select id="taskType" onchange="updateWeightField()">
              <option value="task" ${taskData.type === "task" ? "selected" : ""}>Tarefa</option>
              <option value="milestone" ${taskData.type === "milestone" ? "selected" : ""}>Marco</option>
            </select>
          </label>
          <label>
            WBS
            <input type="text" id="taskWbs" value="${taskData.wbs}">
          </label>
          <label>
            Criticidade
            <select id="taskCriticality">
              <option value="LOW" ${taskData.criticality === "LOW" ? "selected" : ""}>Baixa</option>
              <option value="MEDIUM" ${taskData.criticality === "MEDIUM" ? "selected" : ""}>Média</option>
              <option value="HIGH" ${taskData.criticality === "HIGH" ? "selected" : ""}>Alta</option>
              <option value="CRITICAL" ${taskData.criticality === "CRITICAL" ? "selected" : ""}>Crítica</option>
            </select>
          </label>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <label>
            Tarefa Pai (para criar subtarefa)
            <select id="taskParentId" onchange="updateFromParent()">
              <option value="">Nenhuma (Tarefa Principal)</option>
              ${allTasks.map(buildTaskOption).join("")}
            </select>
          </label>
          <label>
            Responsável
            <input type="text" id="taskAssignee" value="${taskData.assignee}" placeholder="Nome do responsável">
          </label>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <label>
            Grupo
            <input type="text" id="taskGroup" value="${taskData.group}" placeholder="Ex: Fundação, Estrutura">
          </label>
          <label>
            Categoria
            <input type="text" id="taskCategory" value="${taskData.category}" placeholder="Ex: Civil, Elétrica">
          </label>
        </div>

        <h3 style="margin-top: 12px; margin-bottom: 8px; font-size: 14px; font-weight: 600;">Datas Planejadas</h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 12px;">
          <label>
            Data de Início *
            <input type="date" id="taskStartDate" value="${taskData.startDate}" required onchange="calculateDates()">
          </label>
          <label>
            Hora de Início
            <input type="time" id="taskStartTime" value="${taskData.startTime}">
          </label>
          <label>
            Data de Término
            <input type="date" id="taskEndDate" value="${taskData.endDate}" onchange="calculateDates()">
          </label>
          <label>
            Duração (dias)
            <input type="number" id="taskDuration" value="${taskData.duration}" min="0" step="0.01">
          </label>
        </div>

        <label>
          Duração em Horas
          <input type="number" id="taskDurationHours" value="${taskData.durationHours}" min="0" step="0.5">
        </label>

        <h3 style="margin-top: 12px; margin-bottom: 8px; font-size: 14px; font-weight: 600;">Datas Reais (Execução)</h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <label>
            Data e Hora de Início Real
            <div style="display: flex; gap: 8px;">
              <input type="datetime-local" id="taskActualStartDate" value="${taskData.actualStartDate}" style="flex: 1;">
              <button type="button" onclick="setTodayDateTime('taskActualStartDate')" style="padding: 6px 12px; font-size: 12px; white-space: nowrap;">📅 HOJE</button>
            </div>
            <small style="color: #64748b;">Preenchido automaticamente ao iniciar (progresso > 0%)</small>
          </label>
          <label>
            Data e Hora de Término Real
            <div style="display: flex; gap: 8px;">
              <input type="datetime-local" id="taskActualEndDate" value="${taskData.actualEndDate}" style="flex: 1;">
              <button type="button" onclick="setTodayDateTime('taskActualEndDate')" style="padding: 6px 12px; font-size: 12px; white-space: nowrap;">📅 HOJE</button>
            </div>
            <small style="color: #64748b;">Preenchido automaticamente ao concluir (100%)</small>
          </label>
        </div>

        <h3 style="margin-top: 12px; margin-bottom: 8px; font-size: 14px; font-weight: 600;">Progresso e Custos</h3>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <label>
            Progresso (%)
            <input type="number" id="taskProgress" value="${taskData.progress}" min="0" max="100" data-previous-value="${taskData.progress}" onchange="updateProgressDate()">
            <div style="display: flex; gap: 4px; margin-top: 8px;">
              <button type="button" onclick="setQuickProgress(0)" style="flex: 1; padding: 6px; font-size: 12px; background: #94a3b8; color: white; border: none; border-radius: 4px; cursor: pointer;">0%</button>
              <button type="button" onclick="setQuickProgress(25)" style="flex: 1; padding: 6px; font-size: 12px; background: #f59e0b; color: white; border: none; border-radius: 4px; cursor: pointer;">25%</button>
              <button type="button" onclick="setQuickProgress(50)" style="flex: 1; padding: 6px; font-size: 12px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer;">50%</button>
              <button type="button" onclick="setQuickProgress(75)" style="flex: 1; padding: 6px; font-size: 12px; background: #8b5cf6; color: white; border: none; border-radius: 4px; cursor: pointer;">75%</button>
              <button type="button" onclick="setQuickProgress(100)" style="flex: 1; padding: 6px; font-size: 12px; background: #10b981; color: white; border: none; border-radius: 4px; cursor: pointer;">100%</button>
            </div>
          </label>
          <label>
            Data de Atualização do Progresso
            <div style="display: flex; gap: 8px;">
              <input type="datetime-local" id="taskProgressUpdateDate" value="${taskData.progressUpdateDate}" style="flex: 1;">
              <button type="button" onclick="setTodayDateTime('taskProgressUpdateDate')" style="padding: 6px 12px; font-size: 12px; white-space: nowrap;">📅 HOJE</button>
            </div>
            <small style="color: #64748b;">Atualizado automaticamente ao mudar o progresso</small>
          </label>
        </div>

        <label>
          Predecessoras (IDs separados por vírgula)
          <input type="text" id="taskPredecessors" value="${taskData.predecessors}" placeholder="Ex: 1, 2, 3">
        </label>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
          <label>
            Custo Estimado
            <input type="number" id="taskEstimatedCost" value="${taskData.estimatedCost}" min="0" step="0.01">
          </label>
          <label>
            Custo Real
            <input type="number" id="taskActualCost" value="${taskData.actualCost}" min="0" step="0.01">
          </label>
          <label>
            Peso
            <input type="number" id="taskWeight" value="${taskData.weight}" min="0" step="0.1">
          </label>
        </div>

        <label>
          Observações
          <textarea id="taskNotes" rows="3" placeholder="Notas adicionais sobre a tarefa">${taskData.notes}</textarea>
        </label>

      </div>
      <div class="row" style="margin-top: 16px; justify-content: flex-end;">
        <button type="button" class="ghost" onclick="document.getElementById('taskDialog').close()">Cancelar</button>
        <button type="submit" id="taskSubmitBtn">Salvar</button>
      </div>
    </form>
      </div>
    </dialog>
  `

  dialog.innerHTML = dialogHTML // Use the generated HTML

  const startDateInput = $("#taskStartDate")
  const endDateInput = $("#taskEndDate")
  const durationInput = $("#taskDuration")
  const durationHoursInput = $("#taskDurationHours")
  const progressInput = $("#taskProgress")
  const progressUpdateDateInput = $("#taskProgressUpdateDate")
  const actualStartDateInput = $("#taskActualStartDate")
  const actualEndDateInput = $("#taskActualEndDate")

  const originalProgress = taskData?.progress || 0

  let isCalculating = false

  const calculateDates = (window.calculateDates = () => {
    if (isCalculating) return
    isCalculating = true

    const startDate = startDateInput.value
    const endDate = endDateInput.value
    const duration = Number.parseInt(durationInput.value) || 0

    if (startDate && endDate) {
      const calc = DateUtils.calcDuration(startDate, endDate)
      durationInput.value = calc
      durationHoursInput.value = calc * 8
    } else if (startDate && duration > 0) {
      const calc = DateUtils.addDays(startDate, duration)
      endDateInput.value = calc
    } else if (endDate && duration > 0) {
      const calc = DateUtils.addDays(endDate, -duration)
      startDateInput.value = calc
    }

    isCalculating = false
  })

  const updateFromParent = (window.updateFromParent = () => {
    const parentId = $("#taskParentId").value
    if (!parentId) {
      const projectId = Number.parseInt($("#selProjectSchedule")?.value)
      const project = Projects.getById(projectId)
      if (project) {
        if (!startDateInput.value && project.startDate) {
          startDateInput.value = project.startDate
        }
        if (!endDateInput.value && project.endDate) {
          endDateInput.value = project.endDate
        }
      }
      return
    }

    const parent = allTasks.find((t) => t.id === Number.parseInt(parentId))
    if (!parent) return

    if (parent.startDate) {
      startDateInput.value = parent.startDate
    }

    if (parent.endDate) {
      endDateInput.value = parent.endDate
    }

    if (parent.startTime) {
      $("#taskStartTime").value = parent.startTime
    }

    if (startDateInput.value && endDateInput.value) {
      const duration = DateUtils.calcDuration(startDateInput.value, endDateInput.value)
      durationInput.value = duration
    }

    if (parent.group && !$("#taskGroup").value) {
      $("#taskGroup").value = parent.group
    }

    if (parent.category && !$("#taskCategory").value) {
      $("#taskCategory").value = parent.category
    }

    if (parent.assignee && !$("#taskAssignee").value) {
      $("#taskAssignee").value = parent.assignee
    }
  })

  const updateWeightField = (window.updateWeightField = () => {
    const type = $("#taskType").value
    const weightInput = $("#taskWeight")
    if (type === "milestone") {
      weightInput.value = 0
    } else if (weightInput.value == 0) {
      weightInput.value = 1
    }
  })

  // Initial setup for when the dialog is shown
  startDateInput.addEventListener("change", calculateDates)
  endDateInput.addEventListener("change", calculateDates)

  durationInput.addEventListener("input", () => {
    if (isCalculating) return
    isCalculating = true
    const days = Number.parseFloat(durationInput.value) || 0
    durationHoursInput.value = (days * 8).toFixed(2)

    // Recalculate end date based on start date + duration
    if (startDateInput.value && days > 0) {
      endDateInput.value = DateUtils.addDays(startDateInput.value, days)
    }
    isCalculating = false
  })

  durationHoursInput.addEventListener("input", () => {
    if (isCalculating) return
    isCalculating = true
    const hours = Number.parseFloat(durationHoursInput.value) || 0
    const days = hours / 8
    durationInput.value = days.toFixed(2)

    // Recalculate end date based on start date + duration
    if (startDateInput.value && days > 0) {
      endDateInput.value = DateUtils.addDays(startDateInput.value, days)
    }
    isCalculating = false
  })

  updateFromParent()
  updateWeightField()

  const form = $("#taskForm")
  let isSubmitting = false

  form.onsubmit = (e) => {
    e.preventDefault()

    if (isSubmitting) {
      console.log("[v0] Form already submitting, ignoring duplicate submission")
      return
    }

    isSubmitting = true
    const submitBtn = $("#taskSubmitBtn")
    submitBtn.disabled = true
    submitBtn.textContent = "Salvando..."

    console.log("[v0] Form submitted, creating/updating task")

    const taskData = {
      projectId: projectId,
      name: $("#taskName").value,
      type: $("#taskType").value,
      wbs: $("#taskWbs").value,
      parentId: $("#taskParentId").value ? Number.parseInt($("#taskParentId").value) : null,
      group: $("#taskGroup").value,
      category: $("#taskCategory").value,
      criticality: $("#taskCriticality").value,
      startDate: $("#taskStartDate").value,
      startTime: $("#taskStartTime").value,
      endDate: $("#taskEndDate").value,
      actualStartDate: $("#taskActualStartDate").value,
      actualEndDate: $("#taskActualEndDate").value,
      duration: Number.parseInt($("#taskDuration").value) || 0,
      durationHours: Number.parseFloat($("#taskDurationHours").value) || 0,
      progress: Number.parseInt($("#taskProgress").value) || 0,
      progressUpdateDate: $("#taskProgressUpdateDate").value,
      predecessors: $("#taskPredecessors").value,
      estimatedCost: Number.parseFloat($("#taskEstimatedCost").value) || 0,
      actualCost: Number.parseFloat($("#taskActualCost").value) || 0,
      weight: Number.parseFloat($("#taskWeight").value) || 0,
      assignee: $("#taskAssignee").value,
      notes: $("#taskNotes").value,
      rowColor: $("#taskRowColor")?.value || "", // Added optional chaining to prevent null error
    }

    console.log("[v0] Task data:", taskData)

    const project = Projects.getById(projectId)
    if (project && project.startDate && taskData.startDate) {
      if (new Date(taskData.startDate) < new Date(project.startDate)) {
        if (!confirm("A data de início da tarefa é anterior à data de início do projeto. Deseja continuar?")) {
          isSubmitting = false
          submitBtn.disabled = false
          submitBtn.textContent = isEdit ? "Salvar" : "Criar"
          return
        }
      }
    }

    if (project && project.endDate && taskData.endDate) {
      if (new Date(taskData.endDate) > new Date(project.endDate)) {
        alert(
          "⚠️ ATENÇÃO: A data de término da tarefa ultrapassa a data de término do projeto. Esta tarefa será marcada como ATRASADA.",
        )
      }
    }

    let createdTask
    if (isEdit) {
      Tasks.update(task.id, taskData)
      console.log("[v0] Task updated:", task.id)
    } else {
      createdTask = Tasks.create(taskData)
      console.log("[v0] Task created:", createdTask)

      if (createdTask && createdTask.parentId) {
        const collapsedState = CollapsedState.get()
        if (collapsedState[createdTask.parentId]) {
          console.log("[v0] Parent task was collapsed, expanding it to show new subtask")
          CollapsedState.set(createdTask.parentId, false)
        }
      }
    }

    dialog.close()
    loadTasksSpreadsheet()
    hasUnsavedChanges = true

    setTimeout(() => {
      isSubmitting = false
    }, 500)
  }

  dialog.showModal()
}

const CollapsedState = {
  get() {
    const state = localStorage.getItem("ppCollapsedTasks")
    return state ? JSON.parse(state) : {}
  },
  set(taskId, collapsed) {
    const state = this.get()
    if (collapsed) {
      state[taskId] = true
    } else {
      delete state[taskId]
    }
    localStorage.setItem("ppCollapsedTasks", JSON.stringify(state))
  },
  isCollapsed(taskId) {
    return this.get()[taskId] === true
  },
  clear() {
    localStorage.removeItem("ppCollapsedTasks")
  },
}

function loadTasksSpreadsheet() {
  const projectId = Number.parseInt($("#selProjectSchedule")?.value)
  if (!projectId) {
    console.log("[v0] No project selected")
    return
  }

  const allTasks = Tasks.getByProject(projectId).sort((a, b) => a.taskId - b.taskId)
  console.log("[v0] loadTasksSpreadsheet - Total tasks:", allTasks.length)
  console.log(
    "[v0] All tasks:",
    allTasks.map((t) => ({ id: t.id, taskId: t.taskId, name: t.name, parentId: t.parentId })),
  )

  const container = $("#scheduleTableContainer")
  if (!container) {
    console.log("[v0] Container not found")
    return
  }

  const collapsedState = CollapsedState.get()
  console.log("[v0] Collapsed state:", collapsedState)

  const isTaskVisible = (task) => {
    let current = task
    while (current.parentId) {
      const parent = allTasks.find((t) => t.id === current.parentId)
      if (!parent) {
        console.log("[v0] Parent not found for task:", task.name, "parentId:", current.parentId)
        break
      }
      if (CollapsedState.isCollapsed(parent.id)) {
        console.log("[v0] Task hidden because parent is collapsed:", task.name, "parent:", parent.name)
        return false
      }
      current = parent
    }
    return true
  }

  const tasks = allTasks.filter(isTaskVisible)
  console.log("[v0] Visible tasks after filter:", tasks.length)
  console.log(
    "[v0] Visible tasks:",
    tasks.map((t) => ({ id: t.id, taskId: t.taskId, name: t.name, parentId: t.parentId })),
  )

  const hiddenSubtasks = allTasks.filter((t) => t.parentId && !tasks.includes(t))
  if (hiddenSubtasks.length > 0) {
    console.log(
      "[v0] WARNING: Hidden subtasks found:",
      hiddenSubtasks.map((t) => ({ id: t.id, name: t.name, parentId: t.parentId })),
    )
  }

  const wbsMap = calculateWBS(allTasks)
  allTasks.forEach((t) => {
    t.wbs = wbsMap[t.id] || t.wbs
  })

  allTasks.sort((a, b) => {
    const aWBS = (a.wbs || "").split(".").map((n) => Number.parseInt(n) || 0)
    const bWBS = (b.wbs || "").split(".").map((n) => Number.parseInt(n) || 0)

    for (let i = 0; i < Math.max(aWBS.length, bWBS.length); i++) {
      const aNum = aWBS[i] || 0
      const bNum = bWBS[i] || 0
      if (aNum !== bNum) return aNum - bNum
    }
    return 0
  })

  console.log(
    "[v0] Tasks after WBS sort:",
    allTasks.map((t) => ({ id: t.id, name: t.name, wbs: t.wbs, parentId: t.parentId })),
  )

  const customColumns = Projects.getById(projectId)?.customColumns || []

  const metrics = ProjectMetrics.calculate(projectId)
  let progressHTML = ""

  if (metrics) {
    const progressColor =
      metrics.progress >= 75
        ? "#10b981"
        : metrics.progress >= 50
          ? "#3b82f6"
          : metrics.progress >= 25
            ? "#f59e0b"
            : "#ef4444"
    const spiColor = metrics.SPI >= 1 ? "#10b981" : metrics.SPI >= 0.9 ? "#f59e0b" : "#ef4444"
    const cpiColor = metrics.CPI >= 1 ? "#10b981" : metrics.CPI >= 0.9 ? "#f59e0b" : "#ef4444"

    progressHTML = `
      <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 8px; margin-bottom: 16px; color: white;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 16px;">
          <div>
            <div style="font-size: 12px; opacity: 0.9; margin-bottom: 4px;">Progresso Físico</div>
            <div style="font-size: 28px; font-weight: 700;">${metrics.progress}%</div>
            <div style="font-size: 11px; opacity: 0.8;">Planejado: ${metrics.plannedProgress}%</div>
          </div>
          <div>
            <div style="font-size: 12px; opacity: 0.9; margin-bottom: 4px;">SPI (Prazo)</div>
            <div style="font-size: 28px; font-weight: 700; color: ${spiColor};">${metrics.SPI}</div>
            <div style="font-size: 11px; opacity: 0.8;">${metrics.scheduleVariance > 0 ? "Adiantado" : "Atrasado"}</div>
          </div>
          <div>
            <div style="font-size: 12px; opacity: 0.9; margin-bottom: 4px;">CPI (Custo)</div>
            <div style="font-size: 28px; font-weight: 700; color: ${cpiColor};">${metrics.CPI}</div>
            <div style="font-size: 11px; opacity: 0.8;">R$ ${metrics.costVariance}</div>
          </div>
          <div>
            <div style="font-size: 12px; opacity: 0.9; margin-bottom: 4px;">Custo Real</div>
            <div style="font-size: 24px; font-weight: 700;">R$ ${metrics.totalActualCost.toFixed(0)}</div>
            <div style="font-size: 11px; opacity: 0.8;">de R$ ${metrics.totalPlannedCost.toFixed(0)}</div>
          </div>
          <div>
            <div style="font-size: 12px; opacity: 0.9; margin-bottom: 4px;">Dias Decorridos</div>
            <div style="font-size: 24px; font-weight: 700;">${metrics.daysElapsed}</div>
            <div style="font-size: 11px; opacity: 0.8;">de ${metrics.daysTotal} dias</div>
          </div>
          <div>
            <div style="font-size: 12px; opacity: 0.9; margin-bottom: 4px;">Horas Trabalhadas</div>
            <div style="font-size: 24px; font-weight: 700;">${metrics.completedHours.toFixed(0)}h</div>
            <div style="font-size: 11px; opacity: 0.8;">de ${metrics.totalPlannedHours.toFixed(0)}h</div>
          </div>
        </div>
      </div>
    `
  }

  const columns = [
    { id: "taskId", label: "ID", width: "60px", editable: false },
    { id: "wbs", label: "WBS", width: "80px", editable: true },
    { id: "name", label: "Nome da Tarefa", width: "250px", editable: true },
    { id: "type", label: "Tipo", width: "100px", editable: true, type: "select", options: ["task", "milestone"] },
    {
      id: "criticality",
      label: "Criticidade",
      width: "110px",
      editable: true,
      type: "select",
      options: ["LOW", "MEDIUM", "HIGH", "CRITICAL"],
    },
    { id: "startDate", label: "Início Plan.", width: "120px", editable: true, type: "date" },
    { id: "actualStartDate", label: "Início Real", width: "120px", editable: true, type: "date" },
    { id: "endDate", label: "Término Plan.", width: "120px", editable: true, type: "date" },
    { id: "actualEndDate", label: "Término Real", width: "120px", editable: true, type: "date" },
    { id: "duration", label: "Duração (d)", width: "100px", editable: true, type: "number" },
    { id: "durationHours", label: "Horas", width: "80px", editable: true, type: "number" },
    { id: "progress", label: "Progresso %", width: "110px", editable: true, type: "number" },
    { id: "weight", label: "Peso", width: "70px", editable: true, type: "number" },
    { id: "assignee", label: "Responsável", width: "150px", editable: true },
    { id: "group", label: "Grupo", width: "120px", editable: true },
    { id: "category", label: "Categoria", width: "120px", editable: true },
    { id: "predecessors", label: "Predecessoras", width: "120px", editable: true },
    { id: "estimatedCost", label: "Custo Est.", width: "100px", editable: true, type: "number" },
    { id: "actualCost", label: "Custo Real", width: "100px", editable: true, type: "number" },
    ...customColumns.map((col) => ({ ...col, editable: true, custom: true })),
    { id: "actions", label: "Ações", width: "150px", editable: false },
  ]

  // Build spreadsheet HTML
  let html =
    progressHTML +
    `
    <div style="margin-bottom: 12px; display: flex; gap: 8px; align-items: center;">
      <button onclick="showCustomColumnDialog(${projectId})" style="padding: 6px 12px; font-size: 13px;">
        ➕ Adicionar Coluna Personalizada
      </button>
      ${customColumns.length > 0 ? `<span style="color: #64748b; font-size: 13px;">${customColumns.length} coluna(s) personalizada(s)</span>` : ""}
    </div>
    <div class="spreadsheet-container">
      <table class="spreadsheet-table">
        <thead>
          <tr>
            ${columns
              .map(
                (col, idx) => `
              <th style="width: ${col.width}; position: relative;" data-col-index="${idx}">
                <span class="col-header-content">${col.label}${col.custom ? " 🔧" : ""}</span>
                <div class="col-resize-handle" data-col-index="${idx}"></div>
              </th>
            `,
              )
              .join("")}
          </tr>
        </thead>
        <tbody>
  `

  tasks.forEach((task, index) => {
    const criticalityColors = {
      LOW: "#94a3b8",
      MEDIUM: "#3b82f6",
      HIGH: "#f59e0b",
      CRITICAL: "#ef4444",
    }

    const isDelayed = Tasks.isTaskDelayed(task.id)

    const hasDateVariance =
      (task.actualStartDate && task.actualStartDate !== task.startDate) ||
      (task.actualEndDate && task.actualEndDate !== task.endDate)

    const delayedStyle = isDelayed ? "background-color: #fee2e2;" : ""
    const varianceStyle = hasDateVariance && !isDelayed ? "background-color: #fef3c7;" : ""
    const rowColorStyle = task.rowColor ? `background-color: ${task.rowColor};` : ""

    const level = Tasks.getTaskLevel(task.id)
    const indent = "  ".repeat(level) + (level > 0 ? "↳ " : "")
    const indentStyle = level > 0 ? `padding-left: ${level * 20}px; font-style: italic;` : ""

    const hasChildren = allTasks.some((t) => t.parentId === task.id)
    const parentStyle = hasChildren ? "font-weight: 600;" : ""

    const isCollapsed = CollapsedState.isCollapsed(task.id)
    const collapseButton = hasChildren
      ? `<button onclick="toggleCollapse(${task.id})" style="background: none; border: none; cursor: pointer; padding: 0 4px; font-size: 14px;" title="${isCollapsed ? "Expandir" : "Recolher"}">${isCollapsed ? "▶" : "▼"}</button>`
      : '<span style="display: inline-block; width: 20px;"></span>'

    html += `<tr data-task-id="${task.id}" style="border-left: 3px solid ${criticalityColors[task.criticality]}; ${delayedStyle} ${varianceStyle} ${rowColorStyle}">`

    columns.forEach((col) => {
      if (col.id === "actions") {
        html += `
          <td class="actions-cell">
            <button onclick="editTask(${task.id})" style="padding: 4px 8px; font-size: 12px;">✏️</button>
            <button onclick="deleteTask(${task.id})" class="danger" style="padding: 4px 8px; font-size: 12px;">🗑️</button>
            <button onclick="changeRowColor(${task.id})" title="Colorir linha" style="padding: 4px 8px; font-size: 12px;">🎨</button>
            ${isDelayed ? '<span title="Tarefa atrasada" style="color: #ef4444; font-size: 16px;">⚠️</span>' : ""}
            ${hasDateVariance && !isDelayed ? '<span title="Datas reais diferentes do planejado" style="color: #f59e0b; font-size: 16px;">📅</span>' : ""}
            ${hasChildren ? '<span title="Tarefa pai (valores calculados)" style="color: #3b82f6; font-size: 16px;">📊</span>' : ""}
          </td>
        `
      } else if (col.id === "name") {
        html += `
          <td class="editable-cell" data-field="${col.id}" data-task-id="${task.id}" data-clean-value="${task[col.id] || ""}" style="${indentStyle} ${parentStyle}">
            <span class="cell-content">${collapseButton}${indent}${task[col.id] || ""}</span>
          </td>
        `
      } else if (col.custom) {
        const customValue = task.customFields?.[col.id] || ""
        html += `
          <td class="editable-cell" data-field="custom_${col.id}" data-task-id="${task.id}" data-type="${col.type || "text"}">
            <span class="cell-content">${customValue}</span>
          </td>
        `
      } else if (col.editable) {
        let value = task[col.id] || ""
        if (col.type === "number" && typeof value === "number") {
          value = value.toFixed(col.id.includes("Cost") ? 2 : 0)
        }
        html += `
          <td class="editable-cell" data-field="${col.id}" data-task-id="${task.id}" data-type="${col.type || "text"}" style="${parentStyle}">
            <span class="cell-content">${value}</span>
          </td>
        `
      } else {
        html += `<td style="${parentStyle}">${task[col.id] || ""}</td>`
      }
    })

    html += "</tr>"
  })

  // Add empty row for quick add
  html += `
    <tr class="empty-row" onclick="quickAddTask(${projectId})">
      <td colspan="${columns.length}" style="text-align: center; color: #94a3b8; cursor: pointer; padding: 16px;">
        + Clique aqui para adicionar uma nova tarefa
      </td>
    </tr>
  `

  html += `
        </tbody>
      </table>
    </div>
  `

  container.innerHTML = html

  $$(".col-resize-handle").forEach((handle) => {
    handle.addEventListener("mousedown", (e) => {
      e.preventDefault()
      const colIndex = Number.parseInt(handle.dataset.colIndex)
      const th = handle.parentElement
      const startX = e.pageX
      const startWidth = th.offsetWidth

      const onMouseMove = (e) => {
        const newWidth = startWidth + (e.pageX - startX)
        if (newWidth > 50) {
          th.style.width = `${newWidth}px`
          columns[colIndex].width = `${newWidth}px`
        }
      }

      const onMouseUp = () => {
        document.removeEventListener("mousemove", onMouseMove)
        document.removeEventListener("mouseup", onMouseUp)
        // Save column widths to project
        Projects.update(projectId, { customColumns })
      }

      document.addEventListener("mousemove", onMouseMove)
      document.addEventListener("mouseup", onMouseUp)
    })
  })

  // Add click handlers for editable cells
  $$(".editable-cell").forEach((cell) => {
    cell.addEventListener("click", () => window.editCell(cell))
  })
}

window.changeRowColor = (taskId) => {
  const task = Tasks.getById(taskId)
  if (!task) return

  const color = prompt(
    "Digite a cor em hexadecimal (ex: #ffeb3b) ou deixe em branco para remover:",
    task.rowColor || "",
  )
  if (color !== null) {
    Tasks.update(taskId, { rowColor: color })
    loadTasksSpreadsheet()
    hasUnsavedChanges = true
  }
}

window.quickAddTask = (projectId) => {
  showTaskDialog(projectId)
}

window.editTask = (id) => {
  const task = Tasks.getById(id)
  if (!task) return
  showTaskDialog(task.projectId, task)
}

window.deleteTask = (id) => {
  console.log("[v0] deleteTask called with id:", id)
  try {
    if (confirm("Tem certeza que deseja excluir esta tarefa? Todas as subtarefas também serão excluídas.")) {
      console.log("[v0] User confirmed deletion")
      const taskBefore = Tasks.getById(id)
      console.log("[v0] Task to delete:", taskBefore)

      Tasks.delete(id)
      console.log("[v0] Task deleted, reloading spreadsheet")

      loadTasksSpreadsheet()
      hasUnsavedChanges = true

      console.log("[v0] Spreadsheet reloaded successfully")
    } else {
      console.log("[v0] User cancelled deletion")
    }
  } catch (error) {
    console.error("[v0] Error deleting task:", error)
    alert("Erro ao excluir tarefa: " + error.message)
  }
}

window.toggleCollapse = (taskId) => {
  const isCollapsed = CollapsedState.isCollapsed(taskId)
  CollapsedState.set(taskId, !isCollapsed)
  loadTasksSpreadsheet()
}

// Global functions
window.editProject = (id) => {
  const project = Projects.getById(id)
  if (!project) return
  showProjectDialog(project)
}

window.deleteProject = (id) => {
  if (confirm("Tem certeza que deseja excluir este projeto?")) {
    Projects.delete(id)
    loadProjects()
    hasUnsavedChanges = true
  }
}

window.editWO = (id) => {
  const wo = WorkOrders.getById(id)
  if (!wo) return
  showWODialog(wo.projectId, wo)
}

window.deleteWO = (id) => {
  if (confirm("Tem certeza que deseja excluir esta ordem de serviço?")) {
    WorkOrders.delete(id)
    loadWorkOrders()
    hasUnsavedChanges = true
  }
}

function loadWorkOrders() {
  const projectId = Number.parseInt($("#selProjectWO")?.value)
  if (!projectId) return

  const workorders = WorkOrders.getByProject(projectId)
  const tbody = $("#woTable tbody")
  if (!tbody) return

  if (workorders.length === 0) {
    tbody.innerHTML =
      '<tr><td colspan="10" style="text-align: center; color: #94a3b8; padding: 24px;">Nenhuma ordem de serviço cadastrada</td></tr>'
    return
  }

  tbody.innerHTML = workorders
    .map((wo) => {
      const task = wo.taskId ? Tasks.getById(wo.taskId) : null
      const metrics = WorkOrders.calculateMetrics(wo)

      const priorityColors = {
        LOW: "#94a3b8",
        MEDIUM: "#3b82f6",
        HIGH: "#f59e0b",
        URGENT: "#ef4444",
      }

      const statusColors = {
        OPEN: "#3b82f6",
        IN_PROGRESS: "#f59e0b",
        COMPLETED: "#10b981",
        CANCELLED: "#64748b",
      }

      let statusIndicator = ""
      if (metrics.isCompleted) {
        statusIndicator = metrics.isDelayed
          ? '<span style="color: #f59e0b;" title="Concluído com atraso">⚠️</span>'
          : '<span style="color: #10b981;" title="Concluído no prazo">✅</span>'
      } else if (metrics.isDelayed) {
        statusIndicator = '<span style="color: #ef4444;" title="Atrasado">🔴</span>'
      } else if (metrics.isOnTrack) {
        statusIndicator = '<span style="color: #10b981;" title="No prazo">🟢</span>'
      } else {
        statusIndicator = '<span style="color: #94a3b8;" title="Não iniciado">⚪</span>'
      }

      const progressBar = `
        <div style="width: 100%; background: #e2e8f0; border-radius: 4px; height: 20px; position: relative; overflow: hidden;">
          <div style="width: ${wo.progress}%; background: ${wo.progress >= 100 ? "#10b981" : wo.progress >= 50 ? "#3b82f6" : "#f59e0b"}; height: 100%; transition: width 0.3s;"></div>
          <span style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 11px; font-weight: 600; color: #1e293b;">${wo.progress}%</span>
        </div>
      `

      const plannedDates = `
        <div style="font-size: 12px;">
          <div><strong>Planejado:</strong></div>
          <div>${wo.startDate || "-"} até ${wo.endDate || "-"}</div>
          ${wo.actualStartDate ? `<div style="color: #64748b; margin-top: 4px;"><strong>Real:</strong></div>` : ""}
          ${wo.actualStartDate ? `<div style="color: #64748b;">${wo.actualStartDate} até ${wo.actualEndDate || "Em andamento"}</div>` : ""}
          ${metrics.scheduleVariance !== 0 ? `<div style="color: ${metrics.scheduleVariance > 0 ? "#ef4444" : "#10b981"}; margin-top: 4px; font-weight: 600;">${metrics.scheduleVariance > 0 ? "+" : ""}${metrics.scheduleVariance} dias</div>` : ""}
        </div>
      `

      const hoursInfo = `
        <div style="font-size: 12px;">
          <div><strong>Estimado:</strong> ${wo.estimatedHours}h</div>
          <div><strong>Real:</strong> ${wo.actualHours}h</div>
          ${metrics.timeVariance !== 0 ? `<div style="color: ${metrics.timeVariance > 0 ? "#ef4444" : "#10b981"}; font-weight: 600;">${metrics.timeVariance > 0 ? "+" : ""}${metrics.timeVariance}h</div>` : ""}
        </div>
      `

      return `
      <tr style="border-left: 3px solid ${priorityColors[wo.priority]};">
        <td>${statusIndicator}</td>
        <td><strong>${wo.number}</strong></td>
        <td>${wo.title}</td>
        <td><span class="badge" style="background: ${priorityColors[wo.priority]}; color: white;">${wo.priority}</span></td>
        <td><span class="badge" style="background: ${statusColors[wo.status]}; color: white;">${wo.status}</span></td>
        <td>${wo.assignee || "-"}</td>
        <td>${plannedDates}</td>
        <td>${hoursInfo}</td>
        <td>${progressBar}</td>
        <td>${task ? `<span style="font-size: 11px;">${task.taskId} - ${task.name}</span>` : "-"}</td>
        <td>
          <button onclick="editWO(${wo.id})" style="padding: 4px 8px; font-size: 12px;">✏️</button>
          <button onclick="deleteWO(${wo.id})" class="danger" style="padding: 4px 8px; font-size: 12px;">🗑️</button>
        </td>
      </tr>
    `
    })
    .join("")
}

function showWODialog(projectId, wo = null) {
  const dialog = $("#woDialog")
  const isEdit = !!wo

  const tasks = Tasks.getByProject(projectId)
  const project = Projects.getById(projectId)

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">${isEdit ? "Editar" : "Nova"} Ordem de Serviço</h2>
    <form id="woForm" style="max-height: 70vh; overflow-y: auto;">
      <div style="display: flex; flex-direction: column; gap: 12px;">
        
        <label>
          Tarefa Vinculada
          <select id="woTaskId" onchange="handleTaskSelection()">
            <option value="">Nenhuma (Manual)</option>
            ${tasks.map((t) => `<option value="${t.id}" ${wo?.taskId === t.id ? "selected" : ""}>${t.taskId} - ${t.name}</option>`).join("")}
          </select>
          <small style="color: #64748b;">Selecione uma tarefa para preencher automaticamente</small>
        </label>

        <label>
          Título *
          <input type="text" id="woTitle" value="${wo?.title || ""}" required>
        </label>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
          <label>
            Prioridade
            <select id="woPriority">
              <option value="LOW" ${wo?.priority === "LOW" ? "selected" : ""}>Baixa</option>
              <option value="MEDIUM" ${wo?.priority === "MEDIUM" ? "selected" : ""}>Média</option>
              <option value="HIGH" ${wo?.priority === "HIGH" ? "selected" : ""}>Alta</option>
              <option value="URGENT" ${wo?.priority === "URGENT" ? "selected" : ""}>Urgente</option>
            </select>
          </label>
          <label>
            Status
            <select id="woStatus" onchange="handleStatusChange()">
              <option value="OPEN" ${wo?.status === "OPEN" ? "selected" : ""}>Aberta</option>
              <option value="IN_PROGRESS" ${wo?.status === "IN_PROGRESS" ? "selected" : ""}>Em Andamento</option>
              <option value="COMPLETED" ${wo?.status === "COMPLETED" ? "selected" : ""}>Concluída</option>
              <option value="CANCELLED" ${wo?.status === "CANCELLED" ? "selected" : ""}>Cancelada</option>
            </select>
          </label>
          <label>
            Responsável
            <input type="text" id="woAssignee" value="${wo?.assignee || ""}">
          </label>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <label>
            Data de Início Planejada
            <input type="date" id="woStartDate" value="${wo?.startDate || project?.startDate || ""}" onchange="handleDateChange()">
          </label>
          <label>
            Data de Término Planejada
            <input type="date" id="woEndDate" value="${wo?.endDate || project?.endDate || ""}" onchange="handleDateChange()">
          </label>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
          <label>
            Data de Início Real
            <input type="date" id="woActualStartDate" value="${wo?.actualStartDate || ""}" readonly style="background: #f1f5f9;">
            <small style="color: #64748b;">Preenchido automaticamente ao iniciar</small>
          </label>
          <label>
            Data de Término Real
            <input type="date" id="woActualEndDate" value="${wo?.actualEndDate || ""}" readonly style="background: #f1f5f9;">
            <small style="color: #64748b;">Preenchido automaticamente ao concluir</small>
          </label>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
          <label>
            Horas Estimadas
            <input type="number" id="woEstimatedHours" min="0" step="0.5" value="${wo?.estimatedHours || 0}" readonly style="background: #f1f5f9;">
            <small style="color: #64748b;">Calculado automaticamente</small>
          </label>
          <label>
            Horas Reais
            <input type="number" id="woActualHours" min="0" step="0.5" value="${wo?.actualHours || 0}" onchange="handleHoursChange()">
          </label>
          <label>
            Progresso (%)
            <input type="number" id="woProgress" min="0" max="100" value="${wo?.progress || 0}" onchange="handleProgressChange()">
          </label>
        </div>

        <div id="woMetrics" style="background: #f8fafc; padding: 12px; border-radius: 8px; border: 1px solid #e2e8f0;">
          <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; font-size: 13px;">
            <div>
              <strong>Horas Restantes:</strong>
              <div id="remainingHours" style="color: #3b82f6; font-weight: 600;">-</div>
            </div>
            <div>
              <strong>Previsão de Término:</strong>
              <div id="estimatedCompletion" style="color: #3b82f6; font-weight: 600;">-</div>
            </div>
            <div>
              <strong>Variação:</strong>
              <div id="variance" style="font-weight: 600;">-</div>
            </div>
          </div>
        </div>

        <label>
          Descrição
          <textarea id="woDescription" rows="4" placeholder="Detalhes da ordem de serviço">${wo?.description || ""}</textarea>
        </label>

      </div>
      <div class="row" style="margin-top: 16px; justify-content: flex-end;">
        <button type="button" class="ghost" onclick="document.getElementById('woDialog').close()">Cancelar</button>
        <button type="submit">Salvar</button>
      </div>
    </form>
  `

  window.handleTaskSelection = () => {
    const taskId = $("#woTaskId").value
    if (!taskId) return

    const autoData = autoPopulateWOFromTask(taskId, projectId)

    $("#woTitle").value = autoData.title || $("#woTitle").value
    $("#woStartDate").value = autoData.startDate || $("#woStartDate").value
    $("#woEndDate").value = autoData.endDate || $("#woEndDate").value
    $("#woActualStartDate").value = autoData.actualStartDate || ""
    $("#woActualEndDate").value = autoData.actualEndDate || ""
    $("#woEstimatedHours").value = autoData.estimatedHours || 0
    $("#woProgress").value = autoData.progress || 0
    $("#woAssignee").value = autoData.assignee || $("#woAssignee").value
    $("#woDescription").value = autoData.description || $("#woDescription").value

    updateMetrics()
  }

  window.handleDateChange = () => {
    const startDate = $("#woStartDate").value
    const endDate = $("#woEndDate").value

    if (startDate && endDate) {
      const estimatedHours = WOAutoCalc.calcEstimatedHours(startDate, endDate)
      $("#woEstimatedHours").value = estimatedHours
    }

    updateMetrics()
  }

  window.handleHoursChange = () => {
    const actualHours = Number.parseFloat($("#woActualHours").value) || 0
    const estimatedHours = Number.parseFloat($("#woEstimatedHours").value) || 0

    if (estimatedHours > 0) {
      const progress = WOAutoCalc.calcProgressFromHours(actualHours, estimatedHours)
      $("#woProgress").value = progress
    }

    updateMetrics()
  }

  window.handleProgressChange = () => {
    const progress = Number.parseInt($("#woProgress").value) || 0

    // Auto-complete when progress reaches 100%
    if (progress >= 100 && !$("#woActualEndDate").value) {
      $("#woActualEndDate").value = new Date().toISOString().split("T")[0]
      $("#woStatus").value = "COMPLETED"
    }

    updateMetrics()
  }

  window.handleStatusChange = () => {
    const status = $("#woStatus").value
    const today = new Date().toISOString().split("T")[0]

    // Auto-set actual start date when status changes to IN_PROGRESS
    if (status === "IN_PROGRESS" && !$("#woActualStartDate").value) {
      $("#woActualStartDate").value = today
    }

    // Auto-set actual end date when status changes to COMPLETED
    if (status === "COMPLETED" && !$("#woActualEndDate").value) {
      $("#woActualEndDate").value = today
      $("#woProgress").value = 100
    }

    updateMetrics()
  }

  function updateMetrics() {
    const estimatedHours = Number.parseFloat($("#woEstimatedHours").value) || 0
    const actualHours = Number.parseFloat($("#woActualHours").value) || 0
    const progress = Number.parseInt($("#woProgress").value) || 0
    const startDate = $("#woStartDate").value
    const endDate = $("#woEndDate").value

    // Calculate remaining hours
    const remaining = WOAutoCalc.calcRemainingHours(estimatedHours, actualHours)
    $("#remainingHours").textContent = `${remaining.toFixed(1)}h`
    $("#remainingHours").style.color = remaining > estimatedHours * 0.2 ? "#3b82f6" : "#f59e0b"

    // Calculate estimated completion
    if (startDate && endDate && progress > 0 && progress < 100) {
      const estimated = WOAutoCalc.calcEstimatedCompletion(startDate, endDate, progress)
      $("#estimatedCompletion").textContent = estimated

      const plannedEnd = new Date(endDate)
      const estimatedEnd = new Date(estimated)
      $("#estimatedCompletion").style.color = estimatedEnd > plannedEnd ? "#ef4444" : "#10b981"
    } else {
      $("#estimatedCompletion").textContent = endDate || "-"
      $("#estimatedCompletion").style.color = "#3b82f6"
    }

    // Calculate variance
    const variance = actualHours - estimatedHours
    if (variance !== 0) {
      $("#variance").textContent = `${variance > 0 ? "+" : ""}${variance.toFixed(1)}h`
      $("#variance").style.color = variance > 0 ? "#ef4444" : "#10b981"
    } else {
      $("#variance").textContent = "No prazo"
      $("#variance").style.color = "#10b981"
    }
  }

  setTimeout(() => {
    if (isEdit) {
      updateMetrics()
    } else {
      window.handleDateChange()
    }
  }, 100)

  const form = $("#woForm")
  form.onsubmit = (e) => {
    e.preventDefault()

    const woData = {
      projectId: projectId,
      title: $("#woTitle").value,
      priority: $("#woPriority").value,
      status: $("#woStatus").value,
      assignee: $("#woAssignee").value,
      startDate: $("#woStartDate").value,
      endDate: $("#woEndDate").value,
      actualStartDate: $("#woActualStartDate").value,
      actualEndDate: $("#woActualEndDate").value,
      estimatedHours: Number.parseFloat($("#woEstimatedHours").value) || 0,
      actualHours: Number.parseFloat($("#woActualHours").value) || 0,
      progress: Number.parseInt($("#woProgress").value) || 0,
      taskId: $("#woTaskId").value ? Number.parseInt($("#woTaskId").value) : null,
      description: $("#woDescription").value,
    }

    if (isEdit) {
      WorkOrders.update(wo.id, woData)
    } else {
      WorkOrders.create(woData)
    }

    dialog.close()
    loadWorkOrders()

    hasUnsavedChanges = true
  }

  dialog.showModal()
}

window.addEventListener("beforeunload", (e) => {
  if (hasUnsavedChanges) {
    e.preventDefault()
    e.returnValue = "Você tem alterações não salvas. Tem certeza que deseja sair sem salvar?"
    return e.returnValue
  }
})

// Initialize
window.addEventListener("DOMContentLoaded", () => {
  // Navigation buttons
  const sections = {
    mHome: "homeSection",
    mProjects: "projectsSection",
    mSchedule: "scheduleSection",
    mWO: "woSection",
    mS: "sSection",
    mMaterials: "materialsSection",
    mAssets: "assetsSection",
    mReports: "reportsSection",
    mData: "dataSection",
  }

  Object.keys(sections).forEach((buttonId) => {
    const sectionId = sections[buttonId]
    $(`#${buttonId}`)?.addEventListener("click", () => {
      showSection(`#${sectionId}`)
      $(`#${buttonId}`).classList.add("active")

      if (sectionId === "projectsSection") {
        loadProjects()
        loadProjectSelects()
      }
    })
  })

  $("#btnNewProject")?.addEventListener("click", () => {
    showProjectDialog()
  })

  $("#btnExport")?.addEventListener("click", () => {
    const dialog = $("#exportDialog")
    const today = new Date().toISOString().split("T")[0]
    $("#exportFilename").value = `planejar-programar-${today}`
    dialog.showModal()
  })

  $("#btnQuickExport")?.addEventListener("click", () => {
    const dialog = $("#exportDialog")
    const today = new Date().toISOString().split("T")[0]
    $("#exportFilename").value = `planejar-programar-${today}`
    dialog.showModal()
  })

  $("#exportForm")?.addEventListener("submit", (e) => {
    e.preventDefault()
    const filename = $("#exportFilename").value
    const author = $("#exportAuthor").value
    const company = $("#exportCompany").value
    ImportExport.export(filename, author, company)
    $("#exportDialog").close()
    alert("Dados exportados com sucesso!")
  })

  // Import
  $("#fileImport")?.addEventListener("change", async (e) => {
    const file = e.target.files[0]
    if (!file) return
    try {
      await ImportExport.import(file)
      alert("Dados importados com sucesso!")
      location.reload()
    } catch (error) {
      alert("Erro ao importar: " + error.message)
    }
  })

  // Clear data
  $("#btnClearData")?.addEventListener("click", () => {
    if (confirm("ATENÇÃO: Todos os dados serão perdidos. Tem certeza?")) {
      if (confirm("Última confirmação: Deseja realmente limpar todos os dados?")) {
        Storage.clear()
        alert("Dados limpos!")
        location.reload()
      }
    }
  })

  // Task button handler
  $("#btnNewTask")?.addEventListener("click", () => {
    const projectId = Number.parseInt($("#selProjectSchedule")?.value)
    if (!projectId) {
      alert("Selecione um projeto primeiro")
      return
    }
    showTaskDialog(projectId)
  })

  $("#btnNewWO")?.addEventListener("click", () => {
    const projectId = Number.parseInt($("#selProjectWO")?.value)
    if (!projectId) {
      alert("Selecione um projeto primeiro")
      return
    }
    showWODialog(projectId)
  })

  // Project select change handlers
  $("#selProjectSchedule")?.addEventListener("change", loadTasksSpreadsheet) // Load spreadsheet on project change
  $("#selProjectWO")?.addEventListener("change", loadWorkOrders)

  // Baseline button handler
  $("#btnBaseline")?.addEventListener("click", () => {
    const projectId = Number.parseInt($("#selProjectSchedule")?.value)
    if (!projectId) {
      alert("Selecione um projeto primeiro")
      return
    }
    window.showBaselineDialog(projectId)
  })

  // S-curve handlers
  $("#selProjectS")?.addEventListener("change", () => {
    loadBaselineSelects()
    drawSCurve()
  })

  $("#btnRefreshS")?.addEventListener("click", drawSCurve)

  // Material and Asset handlers
  $("#btnNewMaterial")?.addEventListener("click", () => {
    const projectId = Number.parseInt($("#selProjectMaterials")?.value)
    if (!projectId) {
      alert("Selecione um projeto primeiro")
      return
    }
    window.showMaterialDialog(projectId)
  })
  $("#selProjectMaterials")?.addEventListener("change", loadMaterials)

  $("#btnNewAsset")?.addEventListener("click", () => {
    const projectId = Number.parseInt($("#selProjectAssets")?.value)
    if (!projectId) {
      alert("Selecione um projeto primeiro")
      return
    }
    window.showAssetDialog(projectId)
  })
  $("#selProjectAssets")?.addEventListener("change", loadAssets)

  $("#btnAssetLog")?.addEventListener("click", () => {
    const projectId = Number.parseInt($("#selProjectAssets")?.value)
    if (!projectId) {
      alert("Selecione um projeto primeiro")
      return
    }
    window.showAssetLogDialog(projectId)
  })

  // Initial load
  loadProjects()
  loadProjectSelects()
})

window.editCell = (cell) => {
  if (cell.classList.contains("editing")) return

  const field = cell.dataset.field
  const taskId = Number.parseInt(cell.dataset.taskId)
  const type = cell.dataset.type || "text"

  let currentValue
  if (field === "name" && cell.dataset.cleanValue !== undefined) {
    currentValue = cell.dataset.cleanValue
  } else {
    currentValue = cell.querySelector(".cell-content").textContent.trim()
  }

  const isCustomField = field.startsWith("custom_")

  cell.classList.add("editing")

  let input
  if (type === "select") {
    input = document.createElement("select")
    const options = {
      type: ["task", "milestone"],
      criticality: ["LOW", "MEDIUM", "HIGH", "CRITICAL"],
    }
    const fieldName = field.replace("custom_", "")
    options[fieldName]?.forEach((opt) => {
      const option = document.createElement("option")
      option.value = opt
      option.textContent = opt
      option.selected = opt === currentValue
      input.appendChild(option)
    })
  } else {
    input = document.createElement("input")
    input.type = type
    input.value = currentValue
    if (type === "number") {
      input.step = field.includes("Cost") ? "0.01" : field === "durationHours" ? "0.5" : "1"
    }
  }

  input.style.width = "100%"
  input.style.padding = "4px"
  input.style.border = "2px solid #3b82f6"
  input.style.borderRadius = "4px"
  input.style.fontSize = "13px"

  cell.innerHTML = ""
  cell.appendChild(input)
  input.focus()
  if (type === "text") input.select()

  const saveEdit = () => {
    const newValue = input.value
    const task = Tasks.getById(taskId)
    if (!task) return

    const updates = {}

    if (isCustomField) {
      const customFieldId = field.replace("custom_", "")
      updates.customFields = { ...task.customFields, [customFieldId]: newValue }
    } else {
      if (type === "number") {
        updates[field] = Number.parseFloat(newValue) || 0
      } else {
        updates[field] = newValue
      }
    }

    Tasks.update(taskId, updates)
    cell.classList.remove("editing")
    loadTasksSpreadsheet()
    hasUnsavedChanges = true
  }

  const cancelEdit = () => {
    cell.classList.remove("editing")
    loadTasksSpreadsheet()
  }

  input.addEventListener("blur", saveEdit)
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault()
      saveEdit()
    } else if (e.key === "Escape") {
      e.preventDefault()
      cancelEdit()
    }
  })
}

window.showCustomColumnDialog = (projectId) => {
  const dialog = document.createElement("dialog")
  dialog.style.padding = "24px"
  dialog.style.borderRadius = "8px"
  dialog.style.border = "none"
  dialog.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)"

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">Adicionar Coluna Personalizada</h2>
    <form id="customColumnForm">
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <label>
          Nome da Coluna *
          <input type="text" id="columnLabel" required placeholder="Ex: Status, Fornecedor">
        </label>
        <label>
          Tipo de Dado
          <select id="columnType">
            <option value="text">Texto</option>
            <option value="number">Número</option>
            <option value="date">Data</option>
          </select>
        </label>
        <label>
          Largura
          <input type="text" id="columnWidth" value="120px" placeholder="Ex: 120px, 200px">
        </label>
      </div>
      <div style="margin-top: 16px; display: flex; gap: 8px; justify-content: flex-end;">
        <button type="button" class="ghost" onclick="this.closest('dialog').close()">Cancelar</button>
        <button type="submit">Adicionar</button>
      </div>
    </form>
  `

  document.body.appendChild(dialog)

  dialog.querySelector("#customColumnForm").onsubmit = (e) => {
    e.preventDefault()
    CustomColumns.addColumn(projectId, {
      label: dialog.querySelector("#columnLabel").value,
      type: dialog.querySelector("#columnType").value,
      width: dialog.querySelector("#columnWidth").value,
    })
    dialog.close()
    document.body.removeChild(dialog)
    loadTasksSpreadsheet()
    hasUnsavedChanges = true
  }

  dialog.showModal()
}

window.showBaselineDialog = (projectId) => {
  const dialog = document.createElement("dialog")
  dialog.style.padding = "24px"
  dialog.style.borderRadius = "8px"
  dialog.style.border = "none"
  dialog.style.boxShadow = "0 4px 6px rgba(0,0,0,0.1)"

  const baselines = Baselines.getByProject(projectId)

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">Gerenciar Baselines</h2>
    <div style="margin-bottom: 16px;">
      <h3 style="font-size: 14px; margin-bottom: 8px;">Criar Nova Baseline</h3>
      <form id="baselineForm" style="display: flex; gap: 8px;">
        <input type="text" id="baselineName" placeholder="Nome da baseline" required style="flex: 1;">
        <button type="submit">Salvar Baseline</button>
      </form>
    </div>
    ${
      baselines.length > 0
        ? `
      <div>
        <h3 style="font-size: 14px; margin-bottom: 8px;">Baselines Salvas</h3>
        <div style="max-height: 200px; overflow-y: auto;">
          ${baselines
            .map(
              (b) => `
            <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px; border-bottom: 1px solid #e2e8f0;">
              <div>
                <div style="font-weight: 600;">${b.name}</div>
                <div style="font-size: 12px; color: #64748b;">${new Date(b.createdAt).toLocaleString()}</div>
              </div>
              <button onclick="deleteBaseline(${b.id})" class="danger" style="padding: 4px 8px; font-size: 12px;">Excluir</button>
            </div>
          `,
            )
            .join("")}
        </div>
      </div>
    `
        : '<p style="color: #64748b; font-size: 13px;">Nenhuma baseline salva ainda.</p>'
    }
    <div style="margin-top: 16px; display: flex; justify-content: flex-end;">
      <button type="button" class="ghost" onclick="this.closest('dialog').close(); this.closest('dialog').remove();"> Fechar</button>
    </div>
  `

  document.body.appendChild(dialog)

  dialog.querySelector("#baselineForm").onsubmit = (e) => {
    e.preventDefault()
    Baselines.create(projectId, dialog.querySelector("#baselineName").value)
    dialog.close()
    document.body.removeChild(dialog)
    alert("Baseline salva com sucesso!")
    loadBaselineSelects()
    hasUnsavedChanges = true
  }

  dialog.showModal()
}

window.deleteBaseline = (id) => {
  if (confirm("Tem certeza que deseja excluir esta baseline?")) {
    Baselines.delete(id)
    location.reload()
    hasUnsavedChanges = true
  }
}

function loadBaselineSelects() {
  const projectId = Number.parseInt($("#selProjectS")?.value)
  if (!projectId) return

  const baselines = Baselines.getByProject(projectId)
  const html =
    '<option value="">Selecione uma baseline</option>' +
    baselines.map((b) => `<option value="${b.id}">${b.name}</option>`).join("")

  const select = $("#selBaselineA")
  if (select) select.innerHTML = html
}

function drawSCurve() {
  const projectId = Number.parseInt($("#selProjectS")?.value)
  if (!projectId) return

  const svg = $("#sCurve")
  if (!svg) return

  const showPlannedProgress = $("#filterPlannedProgress")?.checked !== false
  const showActualProgress = $("#filterActualProgress")?.checked !== false
  const showWeightedProgress = $("#filterWeightedProgress")?.checked !== false
  const showPlannedCost = $("#filterPlannedCost")?.checked !== false
  const showActualCost = $("#filterActualCost")?.checked !== false
  const showPlannedHours = $("#filterPlannedHours")?.checked !== false
  const showActualHours = $("#filterActualHours")?.checked !== false

  const data = ProjectMetrics.generateSCurveData(projectId)
  if (!data || data.length === 0) {
    svg.innerHTML =
      '<text x="50%" y="50%" text-anchor="middle" fill="#94a3b8">Selecione um projeto com tarefas e datas definidas</text>'
    return
  }

  const width = svg.clientWidth || 800
  const height = 360
  const margin = { top: 60, right: 140, bottom: 60, left: 70 }
  const chartWidth = width - margin.left - margin.right
  const chartHeight = height - margin.top - margin.right

  // Find max values
  const maxCost = Math.max(...data.map((d) => Math.max(d.plannedCost, d.actualCost)))
  const maxHours = Math.max(...data.map((d) => Math.max(d.plannedHours, d.actualHours)))
  const maxProgress = 100

  // Determine which scale to use based on active filters
  const showingCost = showPlannedCost || showActualCost
  const showingHours = showPlannedHours || showActualHours
  const showingProgress = showPlannedProgress || showActualProgress || showWeightedProgress

  // Create scales
  const xScale = (day) => margin.left + (day / (data.length - 1)) * chartWidth
  const yScaleCost = (value) => margin.top + chartHeight - (value / (maxCost || 1)) * chartHeight
  const yScaleHours = (value) => margin.top + chartHeight - (value / (maxHours || 1)) * chartHeight
  const yScaleProgress = (value) => margin.top + chartHeight - (value / 100) * chartHeight

  // Build SVG
  let svgContent = `
    <defs>
      <linearGradient id="gradPlanned" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" style="stop-color:#3b82f6;stop-opacity:0.2" />
        <stop offset="100%" style="stop-color:#3b82f6;stop-opacity:0" />
      </linearGradient>
      <linearGradient id="gradActual" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" style="stop-color:#10b981;stop-opacity:0.2" />
        <stop offset="100%" style="stop-color:#10b981;stop-opacity:0" />
      </linearGradient>
    </defs>
  `

  // Grid lines and Y-axis labels
  for (let i = 0; i <= 5; i++) {
    const y = margin.top + (chartHeight / 5) * i
    svgContent += `<line x1="${margin.left}" y1="${y}" x2="${width - margin.right}" y2="${y}" stroke="#e2e8f0" stroke-width="1"/>`

    // Show appropriate scale labels
    if (showingProgress) {
      const value = Math.round((1 - i / 5) * 100)
      svgContent += `<text x="${margin.left - 10}" y="${y + 4}" text-anchor="end" fill="#64748b" font-size="11">${value}%</text>`
    } else if (showingCost) {
      const value = Math.round((1 - i / 5) * maxCost)
      svgContent += `<text x="${margin.left - 10}" y="${y + 4}" text-anchor="end" fill="#64748b" font-size="11">R$ ${value.toLocaleString()}</text>`
    } else if (showingHours) {
      const value = Math.round((1 - i / 5) * maxHours)
      svgContent += `<text x="${margin.left - 10}" y="${y + 4}" text-anchor="end" fill="#64748b" font-size="11">${value}h</text>`
    }
  }

  // Planned progress curve (blue solid)
  if (showPlannedProgress) {
    let path = `M ${xScale(0)} ${yScaleProgress(data[0].plannedProgress)}`
    data.forEach((d, i) => {
      if (i > 0) path += ` L ${xScale(d.day)} ${yScaleProgress(d.plannedProgress)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#3b82f6" stroke-width="3"/>`
  }

  // Actual progress curve (green solid)
  if (showActualProgress) {
    let path = `M ${xScale(0)} ${yScaleProgress(data[0].actualProgress)}`
    data.forEach((d, i) => {
      if (i > 0 && d.actualProgress > 0) path += ` L ${xScale(d.day)} ${yScaleProgress(d.actualProgress)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#10b981" stroke-width="3"/>`
  }

  // Weighted progress curve (purple solid)
  if (showWeightedProgress) {
    let path = `M ${xScale(0)} ${yScaleProgress(data[0].weightedProgress || 0)}`
    data.forEach((d, i) => {
      if (i > 0) path += ` L ${xScale(d.day)} ${yScaleProgress(d.weightedProgress || 0)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#8b5cf6" stroke-width="3"/>`
  }

  // Planned cost curve (blue dashed)
  if (showPlannedCost) {
    let path = `M ${xScale(0)} ${yScaleCost(data[0].plannedCost)}`
    data.forEach((d, i) => {
      if (i > 0) path += ` L ${xScale(d.day)} ${yScaleCost(d.plannedCost)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#3b82f6" stroke-width="2" stroke-dasharray="8,4"/>`
  }

  // Actual cost curve (red dashed)
  if (showActualCost) {
    let path = `M ${xScale(0)} ${yScaleCost(data[0].actualCost)}`
    data.forEach((d, i) => {
      if (i > 0 && d.actualCost > 0) path += ` L ${xScale(d.day)} ${yScaleCost(d.actualCost)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#ef4444" stroke-width="2" stroke-dasharray="8,4"/>`
  }

  // Planned hours curve (cyan dotted)
  if (showPlannedHours) {
    let path = `M ${xScale(0)} ${yScaleHours(data[0].plannedHours)}`
    data.forEach((d, i) => {
      if (i > 0) path += ` L ${xScale(d.day)} ${yScaleHours(d.plannedHours)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#06b6d4" stroke-width="2" stroke-dasharray="2,3"/>`
  }

  // Actual hours curve (orange dotted)
  if (showActualHours) {
    let path = `M ${xScale(0)} ${yScaleHours(data[0].actualHours)}`
    data.forEach((d, i) => {
      if (i > 0 && d.actualHours > 0) path += ` L ${xScale(d.day)} ${yScaleHours(d.actualHours)}`
    })
    svgContent += `<path d="${path}" fill="none" stroke="#f97316" stroke-width="2" stroke-dasharray="2,3"/>`
  }

  // X-axis labels (dates)
  const labelInterval = Math.ceil(data.length / 8)
  data.forEach((d, i) => {
    if (i % labelInterval === 0 || i === data.length - 1) {
      const x = xScale(d.day)
      svgContent += `<text x="${x}" y="${height - 20}" text-anchor="middle" fill="#64748b" font-size="10">${d.date.split("-").slice(1).join("/")}</text>`
    }
  })

  let legendY = margin.top - 40
  const legendX = width - margin.right + 10

  if (showPlannedProgress) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#3b82f6" stroke-width="3"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Progresso Planejado</text>
    `
    legendY += 18
  }

  if (showActualProgress) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#10b981" stroke-width="3"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Progresso Real</text>
    `
    legendY += 18
  }

  if (showWeightedProgress) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#8b5cf6" stroke-width="3"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Progresso Ponderado</text>
    `
    legendY += 18
  }

  if (showPlannedCost) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#3b82f6" stroke-width="2" stroke-dasharray="8,4"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Custo Planejado</text>
    `
    legendY += 18
  }

  if (showActualCost) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#ef4444" stroke-width="2" stroke-dasharray="8,4"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Custo Real</text>
    `
    legendY += 18
  }

  if (showPlannedHours) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#06b6d4" stroke-width="2" stroke-dasharray="2,3"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Horas Planejadas</text>
    `
    legendY += 18
  }

  if (showActualHours) {
    svgContent += `
      <line x1="${legendX}" y1="${legendY}" x2="${legendX + 30}" y2="${legendY}" stroke="#f97316" stroke-width="2" stroke-dasharray="2,3"/>
      <text x="${legendX + 35}" y="${legendY + 4}" fill="#64748b" font-size="10">Horas Reais</text>
    `
    legendY += 18
  }

  // Title
  svgContent += `<text x="${width / 2}" y="25" text-anchor="middle" fill="#1e293b" font-size="16" font-weight="600">Curva S - Análise de Desempenho</text>`

  svg.innerHTML = svgContent

  // Display KPIs
  const metrics = ProjectMetrics.calculate(projectId)
  if (metrics) {
    const kpisDiv = $("#kpis")
    if (kpisDiv) {
      kpisDiv.innerHTML = `
        <div class="card" style="flex: 1;">
          <h4>SPI (Índice de Desempenho de Prazo)</h4>
          <div style="font-size: 32px; font-weight: 700; color: ${metrics.SPI >= 1 ? "#10b981" : "#ef4444"};">${metrics.SPI}</div>
          <p class="muted">${metrics.SPI >= 1 ? "Projeto adiantado" : "Projeto atrasado"}</p>
        </div>
        <div class="card" style="flex: 1;">
          <h4>CPI (Índice de Desempenho de Custo)</h4>
          <div style="font-size: 32px; font-weight: 700; color: ${metrics.CPI >= 1 ? "#10b981" : "#ef4444"};">${metrics.CPI}</div>
          <p class="muted">${metrics.CPI >= 1 ? "Abaixo do orçamento" : "Acima do orçamento"}</p>
        </div>
        <div class="card" style="flex: 1;">
          <h4>Variação de Custo</h4>
          <div style="font-size: 32px; font-weight: 700; color: ${metrics.costVariance >= 0 ? "#10b981" : "#ef4444"};">R$ ${metrics.costVariance}</div>
          <p class="muted">Estimativa no término: R$ ${metrics.estimateAtCompletion}</p>
        </div>
        <div class="card" style="flex: 1;">
          <h4>Variação de Prazo</h4>
          <div style="font-size: 32px; font-weight: 700; color: ${metrics.scheduleVariance >= 0 ? "#10b981" : "#ef4444"};">${metrics.scheduleVariance}%</div>
          <p class="muted">Dias restantes: ${metrics.daysRemaining}</p>
        </div>
      `
    }
  }
}

// Materials management
const Materials = {
  getAll() {
    return Storage.get().materials || []
  },

  getById(id) {
    return this.getAll().find((m) => m.id === id)
  },

  getByProject(projectId) {
    return this.getAll().filter((m) => m.projectId === projectId)
  },

  create(material) {
    const data = Storage.get()
    if (!data.materials) data.materials = []

    const newMaterial = {
      id: Date.now(),
      projectId: material.projectId,
      code: material.code || `MAT-${String(data.materials.length + 1).padStart(3, "0")}`,
      name: material.name || "",
      description: material.description || "",
      unit: material.unit || "UN",
      unitCost: Number.parseFloat(material.unitCost) || 0,
      quantityAvailable: Number.parseFloat(material.quantityAvailable) || 0,
      minStock: Number.parseFloat(material.minStock) || 0,
      supplier: material.supplier || "",
      category: material.category || "",
      createdAt: new Date().toISOString(),
    }

    data.materials.push(newMaterial)
    Storage.set(data)
    return newMaterial
  },

  update(id, updates) {
    const data = Storage.get()
    const index = data.materials.findIndex((m) => m.id === id)
    if (index === -1) return false

    data.materials[index] = { ...data.materials[index], ...updates }
    Storage.set(data)
    return true
  },

  delete(id) {
    const data = Storage.get()
    data.materials = data.materials.filter((m) => m.id !== id)
    data.taskMaterials = (data.taskMaterials || []).filter((tm) => tm.materialId !== id)
    Storage.set(data)
  },
}

// TaskMaterials linking
const TaskMaterials = {
  getAll() {
    return Storage.get().taskMaterials || []
  },

  getByTask(taskId) {
    return this.getAll().filter((tm) => tm.taskId === taskId)
  },

  create(taskMaterial) {
    const data = Storage.get()
    if (!data.taskMaterials) data.taskMaterials = []

    const newTM = {
      id: Date.now(),
      taskId: taskMaterial.taskId,
      materialId: taskMaterial.materialId,
      quantityNeeded: Number.parseFloat(taskMaterial.quantityNeeded) || 0,
      quantityUsed: Number.parseFloat(taskMaterial.quantityUsed) || 0,
      createdAt: new Date().toISOString(),
    }

    data.taskMaterials.push(newTM)
    Storage.set(data)
    return newTM
  },

  update(id, updates) {
    const data = Storage.get()
    const index = data.taskMaterials.findIndex((tm) => tm.id === id)
    if (index === -1) return false

    data.taskMaterials[index] = { ...data.taskMaterials[index], ...updates }
    Storage.set(data)
    return true
  },

  delete(id) {
    const data = Storage.get()
    data.taskMaterials = data.taskMaterials.filter((tm) => tm.id !== id)
    Storage.set(data)
  },
}

// Assets management
const Assets = {
  getAll() {
    return Storage.get().assets || []
  },

  getById(id) {
    return this.getAll().find((a) => a.id === id)
  },

  getByProject(projectId) {
    return this.getAll().filter((a) => a.projectId === projectId)
  },

  create(asset) {
    const data = Storage.get()
    if (!data.assets) data.assets = []

    const newAsset = {
      id: Date.now(),
      projectId: asset.projectId,
      code: asset.code || `EQP-${String(data.assets.length + 1).padStart(3, "0")}`,
      name: asset.name || "",
      type: asset.type || "equipment",
      status: asset.status || "available",
      location: asset.location || "",
      purchaseDate: asset.purchaseDate || "",
      purchaseCost: Number.parseFloat(asset.purchaseCost) || 0,
      hourlyRate: Number.parseFloat(asset.hourlyRate) || 0,
      totalHoursUsed: 0,
      totalDowntime: 0,
      lastMaintenanceDate: asset.lastMaintenanceDate || "",
      nextMaintenanceDate: asset.nextMaintenanceDate || "",
      maintenanceIntervalHours: Number.parseFloat(asset.maintenanceIntervalHours) || 0,
      maintenanceIntervalDays: Number.parseFloat(asset.maintenanceIntervalDays) || 0,
      notes: asset.notes || "",
      createdAt: new Date().toISOString(),
    }

    data.assets.push(newAsset)
    Storage.set(data)
    return newAsset
  },

  update(id, updates) {
    const data = Storage.get()
    const index = data.assets.findIndex((a) => a.id === id)
    if (index === -1) return false

    data.assets[index] = { ...data.assets[index], ...updates }
    Storage.set(data)
    return true
  },

  delete(id) {
    const data = Storage.get()
    data.assets = data.assets.filter((a) => a.id !== id)
    data.assetLogs = (data.assetLogs || []).filter((al) => al.assetId !== id)
    Storage.set(data)
  },

  calculateMetrics(assetId) {
    const logs = AssetLogs.getByAsset(assetId)
    const asset = this.getById(assetId)
    if (!asset) return null

    let totalUptime = 0
    let totalDowntime = 0
    let totalCost = 0

    logs.forEach((log) => {
      const hours = log.hours || 0
      if (log.status === "running") {
        totalUptime += hours
        totalCost += hours * asset.hourlyRate
      } else if (log.status === "stopped") {
        totalDowntime += hours
      }
    })

    const hoursUntilMaintenance =
      asset.maintenanceIntervalHours > 0 ? Math.max(0, asset.maintenanceIntervalHours - totalUptime) : null

    const daysUntilMaintenance =
      asset.maintenanceIntervalDays > 0 && asset.lastMaintenanceDate
        ? (() => {
            const lastMaint = new Date(asset.lastMaintenanceDate)
            const nextMaint = new Date(lastMaint)
            nextMaint.setDate(nextMaint.getDate() + asset.maintenanceIntervalDays)
            const today = new Date()
            const diffTime = nextMaint - today
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
            return Math.max(0, diffDays)
          })()
        : null

    return {
      totalUptime,
      totalDowntime,
      totalCost,
      utilizationRate:
        totalUptime + totalDowntime > 0 ? ((totalUptime / (totalUptime + totalDowntime)) * 100).toFixed(1) : 0,
      hoursUntilMaintenance,
      daysUntilMaintenance,
      maintenanceStatus:
        hoursUntilMaintenance !== null && hoursUntilMaintenance <= 10
          ? "urgent"
          : daysUntilMaintenance !== null && daysUntilMaintenance <= 7
            ? "urgent"
            : "ok",
    }
  },
}

// AssetLogs for tracking usage and downtime
const AssetLogs = {
  getAll() {
    return Storage.get().assetLogs || []
  },

  getByAsset(assetId) {
    return this.getAll().filter((al) => al.assetId === assetId)
  },

  getByTask(taskId) {
    return this.getAll().filter((al) => al.taskId === taskId)
  },

  create(log) {
    const data = Storage.get()
    if (!data.assetLogs) data.assetLogs = []

    const newLog = {
      id: Date.now(),
      assetId: log.assetId,
      taskId: log.taskId || null,
      status: log.status || "running",
      startTime: log.startTime || new Date().toISOString(),
      endTime: log.endTime || "",
      hours: Number.parseFloat(log.hours) || 0,
      notes: log.notes || "",
      createdAt: new Date().toISOString(),
    }

    data.assetLogs.push(newLog)

    // Update asset total hours
    const asset = data.assets.find((a) => a.id === log.assetId)
    if (asset) {
      if (log.status === "running") {
        asset.totalHoursUsed = (asset.totalHoursUsed || 0) + newLog.hours
      } else if (log.status === "stopped") {
        asset.totalDowntime = (asset.totalDowntime || 0) + newLog.hours
      }
    }

    Storage.set(data)
    return newLog
  },

  update(id, updates) {
    const data = Storage.get()
    const index = data.assetLogs.findIndex((al) => al.id === id)
    if (index === -1) return false

    const oldLog = data.assetLogs[index]
    data.assetLogs[index] = { ...oldLog, ...updates }

    // Recalculate asset totals if hours changed
    if (updates.hours !== undefined) {
      const asset = data.assets.find((a) => a.id === oldLog.assetId)
      if (asset) {
        const diff = (updates.hours || 0) - (oldLog.hours || 0)
        if (oldLog.status === "running") {
          asset.totalHoursUsed = (asset.totalHoursUsed || 0) + diff
        } else if (oldLog.status === "stopped") {
          asset.totalDowntime = (asset.totalDowntime || 0) + diff
        }
      }
    }

    Storage.set(data)
    return true
  },

  delete(id) {
    const data = Storage.get()
    const log = data.assetLogs.find((al) => al.id === id)
    if (log) {
      const asset = data.assets.find((a) => a.id === log.assetId)
      if (asset) {
        if (log.status === "running") {
          asset.totalHoursUsed = Math.max(0, (asset.totalHoursUsed || 0) - (log.hours || 0))
        } else if (log.status === "stopped") {
          asset.totalDowntime = Math.max(0, (asset.totalDowntime || 0) - (log.hours || 0))
        }
      }
    }
    data.assetLogs = data.assetLogs.filter((al) => al.id !== id)
    Storage.set(data)
  },
}

function loadMaterials() {
  const projectId = Number.parseInt($("#selProjectMaterials")?.value)
  if (!projectId) return

  const materials = Materials.getByProject(projectId)
  const tbody = $("#materialsTable tbody")
  if (!tbody) return

  tbody.innerHTML = materials
    .map((m) => {
      const stockStatus = m.quantityAvailable <= m.minStock ? "🔴 Baixo" : "🟢 OK"
      const stockColor = m.quantityAvailable <= m.minStock ? "#fee2e2" : "#f0fdf4"

      return `
        <tr style="background-color: ${stockColor};">
          <td>${m.code}</td>
          <td><strong>${m.name}</strong><br><small style="color: #64748b;">${m.description || ""}</small></td>
          <td>${m.category || "-"}</td>
          <td>${m.unit}</td>
          <td>R$ ${m.unitCost.toFixed(2)}</td>
          <td>${m.quantityAvailable}</td>
          <td>${m.minStock}</td>
          <td>${stockStatus}</td>
          <td>${m.supplier || "-"}</td>
          <td>
            <button onclick="editMaterial(${m.id})" style="padding: 4px 8px; font-size: 12px;">✏️</button>
            <button onclick="deleteMaterial(${m.id})" class="danger" style="padding: 4px 8px; font-size: 12px;">🗑️</button>
          </td>
        </tr>
      `
    })
    .join("")
}

function loadAssets() {
  const projectId = Number.parseInt($("#selProjectAssets")?.value)
  if (!projectId) return

  const assets = Assets.getByProject(projectId)
  const tbody = $("#assetsTable tbody")
  if (!tbody) return

  const totalAssets = assets.length
  let assetsRunning = 0
  let maintenanceUrgent = 0
  let totalUtilization = 0

  tbody.innerHTML = assets
    .map((a) => {
      const metrics = Assets.calculateMetrics(a.id)

      if (a.status === "running") assetsRunning++
      if (metrics.maintenanceStatus === "urgent") maintenanceUrgent++
      totalUtilization += Number.parseFloat(metrics.utilizationRate)

      const statusColors = {
        available: "#10b981",
        running: "#3b82f6",
        stopped: "#ef4444",
        maintenance: "#f59e0b",
      }

      const statusLabels = {
        available: "Disponível",
        running: "Em Operação",
        stopped: "Parado",
        maintenance: "Manutenção",
      }

      let maintenanceInfo = "-"
      if (metrics.hoursUntilMaintenance !== null) {
        maintenanceInfo = `${metrics.hoursUntilMaintenance}h`
        if (metrics.maintenanceStatus === "urgent") {
          maintenanceInfo = `⚠️ ${maintenanceInfo}`
        }
      } else if (metrics.daysUntilMaintenance !== null) {
        maintenanceInfo = `${metrics.daysUntilMaintenance}d`
        if (metrics.maintenanceStatus === "urgent") {
          maintenanceInfo = `⚠️ ${maintenanceInfo}`
        }
      }

      return `
        <tr>
          <td>${a.code}</td>
          <td><strong>${a.name}</strong></td>
          <td>${a.type}</td>
          <td><span style="display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: ${statusColors[a.status]}; margin-right: 6px;"></span>${statusLabels[a.status]}</td>
          <td>${a.location || "-"}</td>
          <td>${metrics.totalUptime.toFixed(1)}h</td>
          <td>${metrics.totalDowntime.toFixed(1)}h</td>
          <td>
            <div style="display: flex; align-items: center; gap: 8px;">
              <div style="flex: 1; height: 8px; background: #e2e8f0; border-radius: 4px; overflow: hidden;">
                <div style="width: ${metrics.utilizationRate}%; background: linear-gradient(90deg, #10b981, #3b82f6);"></div>
              </div>
              <span style="font-size: 12px; font-weight: 600;">${metrics.utilizationRate}%</span>
            </div>
          </td>
          <td>${maintenanceInfo}</td>
          <td>
            <button onclick="editAsset(${a.id})" style="padding: 4px 8px; font-size: 12px;">✏️</button>
            <button onclick="deleteAsset(${a.id})" class="danger" style="padding: 4px 8px; font-size: 12px;">🗑️</button>
          </td>
        </tr>
      `
    })
    .join("")

  // Update dashboard metrics
  $("#totalAssets").textContent = totalAssets
  $("#assetsRunning").textContent = assetsRunning
  $("#assetsMaintenanceUrgent").textContent = maintenanceUrgent
  $("#avgUtilization").textContent = totalAssets > 0 ? `${(totalUtilization / totalAssets).toFixed(1)}%` : "0%"
}

window.showMaterialDialog = (projectId, material = null) => {
  const dialog = $("#materialDialog")
  const isEdit = !!material

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">${isEdit ? "Editar" : "Novo"} Material</h2>
    <form id="materialForm">
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Código
          <input type="text" name="code" value="${material?.code || ""}" ${isEdit ? "readonly" : ""}>
        </label>
        <label>
          Categoria
          <input type="text" name="category" value="${material?.category || ""}" placeholder="Ex: Elétrico, Hidráulico">
        </label>
      </div>
      
      <label>
        Nome do Material *
        <input type="text" name="name" value="${material?.name || ""}" required>
      </label>
      
      <label>
        Descrição
        <textarea name="description" rows="2">${material?.description || ""}</textarea>
      </label>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
        <label>
          Unidade *
          <select name="unit" required>
            <option value="UN" ${material?.unit === "UN" ? "selected" : ""}>Unidade</option>
            <option value="M" ${material?.unit === "M" ? "selected" : ""}>Metro</option>
            <option value="M2" ${material?.unit === "M2" ? "selected" : ""}>Metro²</option>
            <option value="M3" ${material?.unit === "M3" ? "selected" : ""}>Metro³</option>
            <option value="KG" ${material?.unit === "KG" ? "selected" : ""}>Quilograma</option>
            <option value="L" ${material?.unit === "L" ? "selected" : ""}>Litro</option>
            <option value="CX" ${material?.unit === "CX" ? "selected" : ""}>Caixa</option>
          </select>
        </label>
        <label>
          Custo Unitário (R$) *
          <input type="number" name="unitCost" value="${material?.unitCost || 0}" step="0.01" min="0" required>
        </label>
        <label>
          Qtd. Disponível *
          <input type="number" name="quantityAvailable" value="${material?.quantityAvailable || 0}" step="0.01" min="0" required>
        </label>
      </div>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Estoque Mínimo
          <input type="number" name="minStock" value="${material?.minStock || 0}" step="0.01" min="0">
        </label>
        <label>
          Fornecedor
          <input type="text" name="supplier" value="${material?.supplier || ""}">
        </label>
      </div>
      
      <div class="row" style="margin-top: 16px; justify-content: flex-end;">
        <button type="button" class="ghost" onclick="document.getElementById('materialDialog').close()">Cancelar</button>
        <button type="submit">${isEdit ? "Salvar" : "Criar"}</button>
      </div>
    </form>
  `

  const form = $("#materialForm")
  form.onsubmit = (e) => {
    e.preventDefault()
    const formData = new FormData(form)
    const data = Object.fromEntries(formData)
    data.projectId = projectId

    if (isEdit) {
      Materials.update(material.id, data)
    } else {
      Materials.create(data)
    }

    dialog.close()
    loadMaterials()
    hasUnsavedChanges = true
  }

  dialog.showModal()
}

window.showAssetDialog = (projectId, asset = null) => {
  const dialog = $("#assetDialog")
  const isEdit = !!asset

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">${isEdit ? "Editar" : "Novo"} Ativo/Equipamento</h2>
    <form id="assetForm" style="max-height: 70vh; overflow-y: auto;">
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Código
          <input type="text" name="code" value="${asset?.code || ""}" ${isEdit ? "readonly" : ""}>
        </label>
        <label>
          Tipo *
          <select name="type" required>
            <option value="equipment" ${asset?.type === "equipment" ? "selected" : ""}>Equipamento</option>
            <option value="vehicle" ${asset?.type === "vehicle" ? "selected" : ""}>Veículo</option>
            <option value="tool" ${asset?.type === "tool" ? "selected" : ""}>Ferramenta</option>
            <option value="machinery" ${asset?.type === "machinery" ? "selected" : ""}>Maquinário</option>
          </select>
        </label>
      </div>
      
      <label>
        Nome do Ativo *
        <input type="text" name="name" value="${asset?.name || ""}" required>
      </label>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Status *
          <select name="status" required>
            <option value="available" ${asset?.status === "available" ? "selected" : ""}>Disponível</option>
            <option value="running" ${asset?.status === "running" ? "selected" : ""}>Em Operação</option>
            <option value="stopped" ${asset?.status === "stopped" ? "selected" : ""}>Parado</option>
            <option value="maintenance" ${asset?.status === "maintenance" ? "selected" : ""}>Em Manutenção</option>
          </select>
        </label>
        <label>
          Localização
          <input type="text" name="location" value="${asset?.location || ""}">
        </label>
      </div>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Data de Aquisição
          <input type="date" name="purchaseDate" value="${asset?.purchaseDate || ""}">
        </label>
        <label>
          Custo de Aquisição (R$)
          <input type="number" name="purchaseCost" value="${asset?.purchaseCost || 0}" step="0.01" min="0">
        </label>
      </div>
      
      <label>
        Taxa por Hora (R$/h)
        <input type="number" name="hourlyRate" value="${asset?.hourlyRate || 0}" step="0.01" min="0">
      </label>
      
      <h3 style="margin-top: 16px; margin-bottom: 12px; font-size: 14px; font-weight: 600;">Manutenção Preventiva</h3>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Última Manutenção
          <input type="date" name="lastMaintenanceDate" value="${asset?.lastMaintenanceDate || ""}">
        </label>
        <label>
          Próxima Manutenção
          <input type="date" name="nextMaintenanceDate" value="${asset?.nextMaintenanceDate || ""}">
        </label>
      </div>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
        <label>
          Intervalo de Manutenção (horas)
          <input type="number" name="maintenanceIntervalHours" value="${asset?.maintenanceIntervalHours || 0}" min="0" placeholder="Ex: 100">
          <small style="color: #64748b;">Deixe 0 para desabilitar</small>
        </label>
        <label>
          Intervalo de Manutenção (dias)
          <input type="number" name="maintenanceIntervalDays" value="${asset?.maintenanceIntervalDays || 0}" min="0" placeholder="Ex: 30">
          <small style="color: #64748b;">Deixe 0 para desabilitar</small>
        </label>
      </div>
      
      <label>
        Observações
        <textarea name="notes" rows="3">${asset?.notes || ""}</textarea>
      </label>
      
      <div class="row" style="margin-top: 16px; justify-content: flex-end;">
        <button type="button" class="ghost" onclick="document.getElementById('assetDialog').close()">Cancelar</button>
        <button type="submit">${isEdit ? "Salvar" : "Criar"}</button>
      </div>
    </form>
  `

  const form = $("#assetForm")
  form.onsubmit = (e) => {
    e.preventDefault()
    const formData = new FormData(form)
    const data = Object.fromEntries(formData)
    data.projectId = projectId

    if (isEdit) {
      Assets.update(asset.id, data)
    } else {
      Assets.create(data)
    }

    dialog.close()
    loadAssets()
    hasUnsavedChanges = true
  }

  dialog.showModal()
}

window.showAssetLogDialog = (projectId) => {
  const dialog = $("#assetLogDialog")
  const assets = Assets.getByProject(projectId)
  const tasks = Tasks.getByProject(projectId)

  dialog.innerHTML = `
    <h2 style="margin-bottom: 16px;">Registrar Uso de Ativo</h2>
    <form id="assetLogForm">
      <label>
        Ativo/Equipamento *
        <select name="assetId" required>
          <option value="">Selecione...</option>
          ${assets.map((a) => `<option value="${a.id}">${a.code} - ${a.name}</option>`).join("")}
        </select>
      </label>
      
      <label>
        Tarefa (opcional)
        <select name="taskId">
          <option value="">Nenhuma</option>
          ${tasks.map((t) => `<option value="${t.id}">${t.wbs} - ${t.name}</option>`).join("")}
        </select>
      </label>
      
      <label>
        Status *
        <select name="status" required>
          <option value="running">Em Operação (Ligado)</option>
          <option value="stopped">Parado (Desligado)</option>
          <option value="maintenance">Em Manutenção</option>
        </select>
      </label>
      
      <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px;">
        <label>
          Data/Hora Início *
          <input type="datetime-local" name="startTime" value="${new Date().toISOString().slice(0, 16)}" required>
        </label>
        <label>
          Data/Hora Fim
          <input type="datetime-local" name="endTime">
        </label>
        <label>
          Horas *
          <input type="number" name="hours" step="0.1" min="0" required>
        </label>
      </div>
      
      <label>
        Observações
        <textarea name="notes" rows="2" placeholder="Ex: Operação normal, Manutenção preventiva, etc."></textarea>
      </label>
      
      <div class="row" style="margin-top: 16px; justify-content: flex-end;">
        <button type="button" class="ghost" onclick="document.getElementById('assetLogDialog').close()">Cancelar</button>
        <button type="submit">Registrar</button>
      </div>
    </form>
  `

  const form = $("#assetLogForm")
  form.onsubmit = (e) => {
    e.preventDefault()
    const formData = new FormData(form)
    const data = Object.fromEntries(formData)

    AssetLogs.create(data)
    dialog.close()
    loadAssets()
    hasUnsavedChanges = true
  }

  dialog.showModal()
}

window.editMaterial = (id) => {
  const material = Materials.getById(id)
  if (material) window.showMaterialDialog(material.projectId, material)
}

window.deleteMaterial = (id) => {
  if (confirm("Tem certeza que deseja excluir este material?")) {
    Materials.delete(id)
    loadMaterials()
    hasUnsavedChanges = true
  }
}

window.editAsset = (id) => {
  const asset = Assets.getById(id)
  if (asset) window.showAssetDialog(asset.projectId, asset)
}

window.deleteAsset = (id) => {
  if (confirm("Tem certeza que deseja excluir este ativo?")) {
    Assets.delete(id)
    loadAssets()
    hasUnsavedChanges = true
  }
}

// <!-- CHANGE: Fixed undeclared variable error by using window.showReportType -->
window.showReportType("overview")

// Report type switching
window.showReportType = (type) => {
  // Update button states
  $$(".report-type-btn").forEach((btn) => btn.classList.remove("active"))
  $(`#btnReport${type.charAt(0).toUpperCase() + type.slice(1)}`).classList.add("active")

  // Hide all report contents
  $$(".report-content").forEach((content) => content.classList.add("hidden"))

  // Show selected report
  $(`#report${type.charAt(0).toUpperCase() + type.slice(1)}`).classList.remove("hidden")

  // Load report data
  loadReportData(type)
}

// Load report data based on type
function loadReportData(type) {
  const projectId = $("#selProjectReports").value
  if (!projectId) {
    return
  }

  const project = Projects.getById(projectId)
  const tasks = Tasks.getAll().filter((t) => t.projectId === projectId)

  switch (type) {
    case "overview":
      generateOverviewReport(project, tasks)
      break
    case "cost":
      generateCostReport(project, tasks)
      break
    case "delayed":
      generateDelayedReport(project, tasks)
      break
    case "trend":
      generateTrendReport(project, tasks)
      break
    case "performance":
      generatePerformanceReport(project, tasks)
      break
    case "custom":
      // Custom report is generated on button click
      break
  }
}

// Generate Overview Report
function generateOverviewReport(project, tasks) {
  // Calculate metrics
  const totalTasks = tasks.length
  const leafTasks = tasks.filter((t) => !tasks.some((child) => child.parentId === t.id))
  const completedTasks = leafTasks.filter((t) => t.progress === 100).length
  const inProgressTasks = leafTasks.filter((t) => t.progress > 0 && t.progress < 100).length
  const notStartedTasks = leafTasks.filter((t) => t.progress === 0).length
  const delayedTasks = leafTasks.filter((t) => {
    if (!t.endDate) return false
    const endDate = new Date(t.endDate)
    const today = new Date()
    return endDate < today && t.progress < 100
  }).length

  const avgProgress =
    leafTasks.length > 0 ? leafTasks.reduce((sum, t) => sum + (t.progress || 0), 0) / leafTasks.length : 0

  // Display metrics
  const metricsHTML = `
    <div class="card" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Total de Tarefas</h4>
      <div style="font-size: 32px; font-weight: 800;">${totalTasks}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Concluídas</h4>
      <div style="font-size: 32px; font-weight: 800;">${completedTasks}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Em Andamento</h4>
      <div style="font-size: 32px; font-weight: 800;">${inProgressTasks}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Atrasadas</h4>
      <div style="font-size: 32px; font-weight: 800;">${delayedTasks}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Progresso Médio</h4>
      <div style="font-size: 32px; font-weight: 800;">${avgProgress.toFixed(1)}%</div>
    </div>
  `
  $("#overviewMetrics").innerHTML = metricsHTML

  // Task status chart
  createChart("chartTaskStatus", "doughnut", {
    labels: ["Concluídas", "Em Andamento", "Não Iniciadas", "Atrasadas"],
    datasets: [
      {
        data: [completedTasks, inProgressTasks, notStartedTasks, delayedTasks],
        backgroundColor: ["#10b981", "#f59e0b", "#94a3b8", "#ef4444"],
      },
    ],
  })

  // Phase progress chart (group by parent tasks)
  const parentTasks = tasks.filter((t) => tasks.some((child) => child.parentId === t.id))
  const phaseLabels = parentTasks.map((t) => t.name)
  const phaseProgress = parentTasks.map((t) => {
    const children = tasks.filter((child) => child.parentId === t.id)
    return children.length > 0
      ? children.reduce((sum, c) => sum + (c.progress || 0), 0) / children.length
      : t.progress || 0
  })

  createChart("chartPhaseProgress", "bar", {
    labels: phaseLabels,
    datasets: [
      {
        label: "Progresso (%)",
        data: phaseProgress,
        backgroundColor: "#3b82f6",
      },
    ],
  })

  // Resource allocation chart
  const resourceMap = {}
  leafTasks.forEach((t) => {
    const responsible = t.assignee || "Não atribuído" // Changed from t.responsible to t.assignee
    resourceMap[responsible] = (resourceMap[responsible] || 0) + 1
  })

  createChart("chartResourceAllocation", "pie", {
    labels: Object.keys(resourceMap),
    datasets: [
      {
        data: Object.values(resourceMap),
        backgroundColor: ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"],
      },
    ],
  })
}

// Generate Cost Report
function generateCostReport(project, tasks) {
  const leafTasks = tasks.filter((t) => !tasks.some((child) => child.parentId === t.id))

  const totalPlannedCost = leafTasks.reduce((sum, t) => sum + (t.estimatedCost || 0), 0) // Changed from t.plannedCost to t.estimatedCost
  const totalActualCost = leafTasks.reduce((sum, t) => sum + (t.actualCost || 0), 0)
  const costVariance = totalActualCost - totalPlannedCost
  const costVariancePercent = totalPlannedCost > 0 ? (costVariance / totalPlannedCost) * 100 : 0

  const metricsHTML = `
    <div class="card" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Custo Planejado</h4>
      <div style="font-size: 28px; font-weight: 800;">R$ ${totalPlannedCost.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, ${costVariance > 0 ? "#ef4444, #dc2626" : "#10b981, #059669"}); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Custo Real</h4>
      <div style="font-size: 28px; font-weight: 800;">R$ ${totalActualCost.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, ${costVariance > 0 ? "#f59e0b, #d97706" : "#10b981, #059669"}); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Desvio</h4>
      <div style="font-size: 28px; font-weight: 800;">${costVariance > 0 ? "+" : ""}R$ ${costVariance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
      <div style="font-size: 14px; opacity: 0.9;">${costVariancePercent > 0 ? "+" : ""}${costVariancePercent.toFixed(1)}%</div>
    </div>
  `
  $("#costMetrics").innerHTML = metricsHTML

  // Cost trend over time
  const sortedTasks = [...leafTasks].sort((a, b) => {
    const dateA = new Date(a.startDate || 0)
    const dateB = new Date(b.startDate || 0)
    return dateA - dateB
  })

  let cumulativePlanned = 0
  let cumulativeActual = 0
  const trendData = sortedTasks.map((t) => {
    cumulativePlanned += t.estimatedCost || 0 // Changed from t.plannedCost to t.estimatedCost
    cumulativeActual += t.actualCost || 0
    return {
      date: t.startDate,
      planned: cumulativePlanned,
      actual: cumulativeActual,
    }
  })

  createChart("chartCostTrend", "line", {
    labels: trendData.map((d) => formatDateBR(d.date)),
    datasets: [
      {
        label: "Custo Planejado",
        data: trendData.map((d) => d.planned),
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59, 130, 246, 0.1)",
        fill: true,
      },
      {
        label: "Custo Real",
        data: trendData.map((d) => d.actual),
        borderColor: "#ef4444",
        backgroundColor: "rgba(239, 68, 68, 0.1)",
        fill: true,
      },
    ],
  })

  // Cost by category (group by parent)
  const categoryMap = {}
  leafTasks.forEach((t) => {
    const parent = tasks.find((p) => p.id === t.parentId)
    const category = parent ? parent.name : "Sem categoria"
    categoryMap[category] = (categoryMap[category] || 0) + (t.actualCost || 0)
  })

  createChart("chartCostByCategory", "bar", {
    labels: Object.keys(categoryMap),
    datasets: [
      {
        label: "Custo Real (R$)",
        data: Object.values(categoryMap),
        backgroundColor: "#10b981",
      },
    ],
  })

  // Cost variance chart
  const varianceData = leafTasks
    .map((t) => ({
      name: t.name,
      variance: (t.actualCost || 0) - (t.estimatedCost || 0), // Changed from t.plannedCost to t.estimatedCost
    }))
    .filter((d) => d.variance !== 0)
    .sort((a, b) => Math.abs(b.variance) - Math.abs(a.variance))
    .slice(0, 10)

  createChart(
    "chartCostVariance",
    "bar",
    {
      labels: varianceData.map((d) => d.name),
      datasets: [
        {
          label: "Desvio de Custo (R$)",
          data: varianceData.map((d) => d.variance),
          backgroundColor: varianceData.map((d) => (d.variance > 0 ? "#ef4444" : "#10b981")),
        },
      ],
    },
    {
      indexAxis: "y",
    },
  )

  // Cost details table
  const tableHTML = leafTasks
    .map((t) => {
      const planned = t.estimatedCost || 0 // Changed from t.plannedCost to t.estimatedCost
      const actual = t.actualCost || 0
      const variance = actual - planned
      const variancePercent = planned > 0 ? (variance / planned) * 100 : 0
      const status = variance > planned * 0.1 ? "🔴 Acima" : variance < -planned * 0.1 ? "🟢 Abaixo" : "🟡 Normal"

      return `
      <tr>
        <td>${t.name}</td>
        <td>R$ ${planned.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
        <td>R$ ${actual.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</td>
        <td style="color: ${variance > 0 ? "#ef4444" : "#10b981"};">
          ${variance > 0 ? "+" : ""}R$ ${variance.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
        </td>
        <td style="color: ${variance > 0 ? "#ef4444" : "#10b981"};">
          ${variancePercent > 0 ? "+" : ""}${variancePercent.toFixed(1)}%
        </td>
        <td>${status}</td>
      </tr>
    `
    })
    .join("")

  $("#costDetailsTable tbody").innerHTML = tableHTML
}

// Generate Delayed Tasks Report
function generateDelayedReport(project, tasks) {
  const today = new Date()
  const leafTasks = tasks.filter((t) => !tasks.some((child) => child.parentId === t.id))
  const delayedTasks = leafTasks.filter((t) => {
    if (!t.endDate || t.progress === 100) return false
    const endDate = new Date(t.endDate)
    return endDate < today
  })

  const totalDelayed = delayedTasks.length
  const avgDelay =
    delayedTasks.length > 0
      ? delayedTasks.reduce((sum, t) => {
          const endDate = new Date(t.endDate)
          const diffTime = today - endDate
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
          return sum + diffDays
        }, 0) / delayedTasks.length
      : 0

  const criticalDelayed = delayedTasks.filter((t) => {
    const endDate = new Date(t.endDate)
    const diffTime = today - endDate
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 7
  }).length

  const metricsHTML = `
    <div class="card" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Tarefas Atrasadas</h4>
      <div style="font-size: 32px; font-weight: 800;">${totalDelayed}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Atraso Médio</h4>
      <div style="font-size: 32px; font-weight: 800;">${avgDelay.toFixed(0)} dias</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Críticas (>7 dias)</h4>
      <div style="font-size: 32px; font-weight: 800;">${criticalDelayed}</div>
    </div>
  `
  $("#delayedMetrics").innerHTML = metricsHTML

  // Delay impact chart
  const delayByPhase = {}
  delayedTasks.forEach((t) => {
    const parent = tasks.find((p) => p.id === t.parentId)
    const phase = parent ? parent.name : "Sem fase"
    delayByPhase[phase] = (delayByPhase[phase] || 0) + 1
  })

  createChart("chartDelayImpact", "bar", {
    labels: Object.keys(delayByPhase),
    datasets: [
      {
        label: "Tarefas Atrasadas",
        data: Object.values(delayByPhase),
        backgroundColor: "#ef4444",
      },
    ],
  })

  // Delayed tasks table
  const tableHTML = delayedTasks
    .map((t) => {
      const endDate = new Date(t.endDate)
      const diffTime = today - endDate
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      const impact = diffDays > 14 ? "🔴 Alto" : diffDays > 7 ? "🟡 Médio" : "🟢 Baixo"

      return `
      <tr>
        <td>${t.wbs || "-"}</td>
        <td>${t.name}</td>
        <td>${t.assignee || "-"}</td> {/* Changed from t.responsible to t.assignee */}
        <td>${formatDateBR(t.endDate)}</td>
        <td style="color: #ef4444; font-weight: 600;">${diffDays} dias</td>
        <td>
          <div style="background: #e5e7eb; border-radius: 4px; height: 20px; overflow: hidden;">
            <div style="background: ${t.progress === 100 ? "#10b981" : t.progress > 50 ? "#f59e0b" : "#ef4444"}; width: ${t.progress}%; height: 100%; display: flex; align-items: center; justify-content: center; color: white; font-size: 11px; font-weight: 600;">
              ${t.progress}%
            </div>
          </div>
        </td>
        <td>${impact}</td>
        <td>
          <button onclick="showTaskDialog(${t.id})" style="padding: 4px 8px; font-size: 12px;">Editar</button>
        </td>
      </tr>
    `
    })
    .join("")

  $("#delayedTasksTable tbody").innerHTML = tableHTML
}

// Generate Trend Report
function generateTrendReport(project, tasks) {
  const leafTasks = tasks.filter((t) => !tasks.some((child) => child.parentId === t.id))

  // Calculate velocity (tasks completed per week)
  const completedTasks = leafTasks.filter((t) => t.progress === 100 && t.actualEndDate)
  const sortedCompleted = [...completedTasks].sort((a, b) => {
    const dateA = new Date(a.actualEndDate)
    const dateB = new Date(b.actualEndDate)
    return dateA - dateB
  })

  const weeklyCompletion = {}
  sortedCompleted.forEach((t) => {
    const date = new Date(t.actualEndDate)
    const weekStart = new Date(date)
    weekStart.setDate(date.getDate() - date.getDay())
    const weekKey = weekStart.toISOString().split("T")[0]
    weeklyCompletion[weekKey] = (weeklyCompletion[weekKey] || 0) + 1
  })

  const avgVelocity =
    Object.values(weeklyCompletion).length > 0
      ? Object.values(weeklyCompletion).reduce((a, b) => a + b, 0) / Object.values(weeklyCompletion).length
      : 0

  const remainingTasks = leafTasks.filter((t) => t.progress < 100).length
  const estimatedWeeks = avgVelocity > 0 ? Math.ceil(remainingTasks / avgVelocity) : 0

  const today = new Date()
  const estimatedCompletion = new Date(today)
  estimatedCompletion.setDate(today.getDate() + estimatedWeeks * 7)

  const metricsHTML = `
    <div class="card" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Velocidade Média</h4>
      <div style="font-size: 28px; font-weight: 800;">${avgVelocity.toFixed(1)} tarefas/semana</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Tarefas Restantes</h4>
      <div style="font-size: 28px; font-weight: 800;">${remainingTasks}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Conclusão Estimada</h4>
      <div style="font-size: 24px; font-weight: 800;">${formatDateBR(estimatedCompletion.toISOString().split("T")[0])}</div>
      <div style="font-size: 14px; opacity: 0.9;">Em ${estimatedWeeks} semanas</div>
    </div>
  `
  $("#trendMetrics").innerHTML = metricsHTML

  // Progress trend with projection
  const progressHistory = []
  const sortedTasks = [...leafTasks].sort((a, b) => {
    const dateA = new Date(a.startDate || 0)
    const dateB = new Date(b.startDate || 0)
    return dateA - dateB
  })

  let cumulativeProgress = 0
  sortedTasks.forEach((t, i) => {
    cumulativeProgress += t.progress || 0
    progressHistory.push({
      date: t.startDate,
      progress: cumulativeProgress / (i + 1),
    })
  })

  // Add projection
  const lastProgress = progressHistory[progressHistory.length - 1]?.progress || 0
  const progressRate =
    progressHistory.length > 1 ? (lastProgress - progressHistory[0].progress) / progressHistory.length : 0

  const projectionPoints = []
  for (let i = 1; i <= 10; i++) {
    const futureDate = new Date(today)
    futureDate.setDate(today.getDate() + i * 7)
    const projectedProgress = Math.min(100, lastProgress + progressRate * i)
    projectionPoints.push({
      date: futureDate.toISOString().split("T")[0],
      progress: projectedProgress,
    })
  }

  createChart("chartProgressTrend", "line", {
    labels: [...progressHistory.map((d) => formatDateBR(d.date)), ...projectionPoints.map((d) => formatDateBR(d.date))],
    datasets: [
      {
        label: "Progresso Real",
        data: [...progressHistory.map((d) => d.progress), ...Array(projectionPoints.length).fill(null)],
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59, 130, 246, 0.1)",
        fill: true,
      },
      {
        label: "Projeção",
        data: [...Array(progressHistory.length).fill(null), ...projectionPoints.map((d) => d.progress)],
        borderColor: "#8b5cf6",
        borderDash: [5, 5],
        backgroundColor: "rgba(139, 92, 246, 0.1)",
        fill: true,
      },
    ],
  })

  // Cost projection
  const costHistory = []
  let cumulativeCost = 0
  sortedTasks.forEach((t) => {
    cumulativeCost += t.actualCost || 0
    costHistory.push({
      date: t.startDate,
      cost: cumulativeCost,
    })
  })

  const avgCostPerTask = cumulativeCost / completedTasks.length || 0
  const projectedTotalCost = avgCostPerTask * leafTasks.length

  createChart("chartCostProjection", "line", {
    labels: costHistory.map((d) => formatDateBR(d.date)),
    datasets: [
      {
        label: "Custo Acumulado",
        data: costHistory.map((d) => d.cost),
        borderColor: "#10b981",
        backgroundColor: "rgba(16, 185, 129, 0.1)",
        fill: true,
      },
      {
        label: "Projeção Final",
        data: Array(costHistory.length).fill(projectedTotalCost),
        borderColor: "#f59e0b",
        borderDash: [5, 5],
      },
    ],
  })

  // Velocity chart
  createChart("chartVelocity", "bar", {
    labels: Object.keys(weeklyCompletion).map((d) => formatDateBR(d)),
    datasets: [
      {
        label: "Tarefas Concluídas",
        data: Object.values(weeklyCompletion),
        backgroundColor: "#3b82f6",
      },
    ],
  })

  // Forecast details
  const forecastHTML = `
    <h4 style="margin-bottom: 12px;">Previsões Baseadas em Tendências Atuais</h4>
    <div style="display: grid; gap: 12px;">
      <div style="padding: 12px; background: white; border-radius: 6px; border-left: 4px solid #3b82f6;">
        <strong>Data de Conclusão Estimada:</strong> ${formatDateBR(estimatedCompletion.toISOString().split("T")[0])}
        <p style="margin: 4px 0 0; font-size: 13px; color: #64748b;">
          Baseado na velocidade média de ${avgVelocity.toFixed(1)} tarefas por semana
        </p>
      </div>
      <div style="padding: 12px; background: white; border-radius: 6px; border-left: 4px solid #10b981;">
        <strong>Custo Total Projetado:</strong> R$ ${projectedTotalCost.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
        <p style="margin: 4px 0 0; font-size: 13px; color: #64748b;">
          Baseado no custo médio de R$ ${avgCostPerTask.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} por tarefa
        </p>
      </div>
      <div style="padding: 12px; background: white; border-radius: 6px; border-left: 4px solid #f59e0b;">
        <strong>Taxa de Progresso:</strong> ${progressRate.toFixed(2)}% por período
        <p style="margin: 4px 0 0; font-size: 13px; color: #64748b;">
          ${progressRate > 0 ? "Tendência positiva de crescimento" : "Atenção: progresso estagnado"}
        </p>
      </div>
    </div>
  `
  $("#forecastDetails").innerHTML = forecastHTML
}

// Generate Performance (EVM) Report
function generatePerformanceReport(project, tasks) {
  const leafTasks = tasks.filter((t) => !tasks.some((child) => child.parentId === t.id))

  // Calculate EVM metrics
  const totalPlannedValue = leafTasks.reduce((sum, t) => sum + (t.estimatedCost || 0), 0) // Changed from t.plannedCost to t.estimatedCost
  const earnedValue = leafTasks.reduce((sum, t) => sum + ((t.estimatedCost || 0) * (t.progress || 0)) / 100, 0) // Changed from t.plannedCost to t.estimatedCost
  const actualCost = leafTasks.reduce((sum, t) => sum + (t.actualCost || 0), 0)

  const costVariance = earnedValue - actualCost
  const scheduleVariance =
    earnedValue -
    totalPlannedValue * (leafTasks.reduce((sum, t) => sum + (t.progress || 0), 0) / leafTasks.length / 100) // Changed from t.plannedCost to totalPlannedValue (which is now estimatedCost)

  const cpi = actualCost > 0 ? earnedValue / actualCost : 0
  const spi = totalPlannedValue > 0 ? earnedValue / totalPlannedValue : 0

  const metricsHTML = `
    <div class="card" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Valor Planejado (PV)</h4>
      <div style="font-size: 24px; font-weight: 800;">R$ ${totalPlannedValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Valor Agregado (EV)</h4>
      <div style="font-size: 24px; font-weight: 800;">R$ ${earnedValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">Custo Real (AC)</h4>
      <div style="font-size: 24px; font-weight: 800;">R$ ${actualCost.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, ${cpi >= 1 ? "#10b981, #059669" : "#ef4444, #dc2626"}); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">CPI (Índice de Desempenho de Custo)</h4>
      <div style="font-size: 32px; font-weight: 800;">${cpi.toFixed(2)}</div>
      <div style="font-size: 14px; opacity: 0.9;">${cpi >= 1 ? "Dentro do orçamento" : "Acima do orçamento"}</div>
    </div>
    <div class="card" style="background: linear-gradient(135deg, ${spi >= 1 ? "#10b981, #059669" : "#f59e0b, #d97706"}); color: white;">
      <h4 style="color: white; margin-bottom: 8px;">SPI (Índice de Desempenho de Prazo)</h4>
      <div style="font-size: 32px; font-weight: 800;">${spi.toFixed(2)}</div>
      <div style="font-size: 14px; opacity: 0.9;">${spi >= 1 ? "Dentro do prazo" : "Atrasado"}</div>
    </div>
  `
  $("#evmMetrics").innerHTML = metricsHTML

  // EVM curve
  const sortedTasks = [...leafTasks].sort((a, b) => {
    const dateA = new Date(a.startDate || 0)
    const dateB = new Date(b.startDate || 0)
    return dateA - dateB
  })

  let cumulativePV = 0
  let cumulativeEV = 0
  let cumulativeAC = 0

  const evmData = sortedTasks.map((t) => {
    cumulativePV += t.estimatedCost || 0 // Changed from t.plannedCost to t.estimatedCost
    cumulativeEV += ((t.estimatedCost || 0) * (t.progress || 0)) / 100 // Changed from t.plannedCost to t.estimatedCost
    cumulativeAC += t.actualCost || 0

    return {
      date: t.startDate,
      pv: cumulativePV,
      ev: cumulativeEV,
      ac: cumulativeAC,
    }
  })

  createChart("chartEVM", "line", {
    labels: evmData.map((d) => formatDateBR(d.date)),
    datasets: [
      {
        label: "Valor Planejado (PV)",
        data: evmData.map((d) => d.pv),
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59, 130, 246, 0.1)",
        fill: false,
      },
      {
        label: "Valor Agregado (EV)",
        data: evmData.map((d) => d.ev),
        borderColor: "#10b981",
        backgroundColor: "rgba(16, 185, 129, 0.1)",
        fill: false,
      },
      {
        label: "Custo Real (AC)",
        data: evmData.map((d) => d.ac),
        borderColor: "#ef4444",
        backgroundColor: "rgba(239, 68, 68, 0.1)",
        fill: false,
      },
    ],
  })

  // Performance indexes
  createChart(
    "chartPerformanceIndexes",
    "bar",
    {
      labels: ["CPI", "SPI"],
      datasets: [
        {
          label: "Índice",
          data: [cpi, spi],
          backgroundColor: [cpi >= 1 ? "#10b981" : "#ef4444", spi >= 1 ? "#10b981" : "#f59e0b"],
        },
      ],
    },
    {
      scales: {
        y: {
          beginAtZero: true,
          max: 2,
        },
      },
    },
  )

  // Variances
  createChart(
    "chartVariances",
    "bar",
    {
      labels: ["Variação de Custo (CV)", "Variação de Prazo (SV)"],
      datasets: [
        {
          label: "Variação (R$)",
          data: [costVariance, scheduleVariance],
          backgroundColor: [costVariance >= 0 ? "#10b981" : "#ef4444", scheduleVariance >= 0 ? "#10b981" : "#f59e0b"],
        },
      ],
    },
    {
      indexAxis: "y",
    },
  )
}

// Helper function to create charts
function createChart(canvasId, type, data, options = {}) {
  const canvas = $(`#${canvasId}`)
  if (!canvas) return

  // Destroy existing chart if it exists
  if (window.reportCharts[canvasId]) {
    window.reportCharts[canvasId].destroy()
  }

  const ctx = canvas.getContext("2d")

  // Default options
  const defaultOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: "top",
      },
    },
  }

  // Merge options
  const finalOptions = {
    ...defaultOptions,
    ...options,
  }

  // Create chart
  window.reportCharts[canvasId] = new Chart(ctx, {
    type: type,
    data: data,
    options: finalOptions,
  })
}

// Generate custom report
$("#btnGenerateCustomReport")?.addEventListener("click", () => {
  const projectId = $("#selProjectReports").value
  if (!projectId) {
    alert("Selecione um projeto")
    return
  }

  const project = Projects.getById(projectId)
  const allTasks = Tasks.getAll().filter((t) => t.projectId === projectId)

  // Apply filters
  const startDate = $("#customReportStartDate").value
  const endDate = $("#customReportEndDate").value
  const selectedStatus = Array.from($("#customReportStatus").selectedOptions).map((o) => o.value)
  const responsible = $("#customReportResponsible").value

  let filteredTasks = allTasks.filter((t) => !allTasks.some((child) => child.parentId === t.id))

  if (startDate) {
    filteredTasks = filteredTasks.filter((t) => t.startDate >= startDate)
  }
  if (endDate) {
    filteredTasks = filteredTasks.filter((t) => t.endDate <= endDate)
  }
  if (selectedStatus.length > 0) {
    filteredTasks = filteredTasks.filter((t) => {
      if (selectedStatus.includes("not-started") && t.progress === 0) return true
      if (selectedStatus.includes("in-progress") && t.progress > 0 && t.progress < 100) return true
      if (selectedStatus.includes("completed") && t.progress === 100) return true
      if (selectedStatus.includes("delayed")) {
        const today = new Date()
        const endDate = new Date(t.endDate)
        return endDate < today && t.progress < 100
      }
      return false
    })
  }
  if (responsible) {
    filteredTasks = filteredTasks.filter((t) => t.assignee === responsible) // Changed from t.responsible to t.assignee
  }

  // Get selected metrics
  const showProgress = $("#metricProgress").checked
  const showCost = $("#metricCost").checked
  const showHours = $("#metricHours").checked
  const showDelay = $("#metricDelay").checked

  // Get chart type
  const chartType = $("#customChartType").value

  // Generate report
  let reportHTML = `
    <div class="card">
      <h3>Relatório Personalizado</h3>
      <p style="color: #64748b; margin-top: 8px;">
        ${filteredTasks.length} tarefas encontradas com os filtros aplicados
      </p>
    </div>
  `

  if (showProgress) {
    const avgProgress = filteredTasks.reduce((sum, t) => sum + (t.progress || 0), 0) / filteredTasks.length
    reportHTML += `
      <div class="card">
        <h4>Progresso Médio: ${avgProgress.toFixed(1)}%</h4>
        <canvas id="customChartProgress" width="100%" height="300"></canvas>
      </div>
    `
  }

  if (showCost) {
    const totalPlanned = filteredTasks.reduce((sum, t) => sum + (t.estimatedCost || 0), 0) // Changed from t.plannedCost to t.estimatedCost
    const totalActual = filteredTasks.reduce((sum, t) => sum + (t.actualCost || 0), 0)
    reportHTML += `
      <div class="card">
        <h4>Custos: Planejado R$ ${totalPlanned.toLocaleString("pt-BR", { minimumFractionDigits: 2 })} | Real R$ ${totalActual.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}</h4>
        <canvas id="customChartCost" width="100%" height="300"></canvas>
      </div>
    `
  }

  if (showHours) {
    const totalPlannedHours = filteredTasks.reduce((sum, t) => sum + (t.durationHours || 0), 0)
    const totalActualHours = filteredTasks.reduce((sum, t) => sum + (t.actualHours || 0), 0)
    reportHTML += `
      <div class="card">
        <h4>Horas: Planejadas ${totalPlannedHours.toFixed(1)}h | Reais ${totalActualHours.toFixed(1)}h</h4>
        <canvas id="customChartHours" width="100%" height="300"></canvas>
      </div>
    `
  }

  $("#customReportResults").innerHTML = reportHTML

  // Create charts
  setTimeout(() => {
    if (showProgress) {
      createChart("customChartProgress", chartType, {
        labels: filteredTasks.map((t) => t.name),
        datasets: [
          {
            label: "Progresso (%)",
            data: filteredTasks.map((t) => t.progress || 0),
            backgroundColor: "#3b82f6",
          },
        ],
      })
    }

    if (showCost) {
      createChart("customChartCost", chartType === "pie" || chartType === "doughnut" ? chartType : "bar", {
        labels: filteredTasks.map((t) => t.name),
        datasets: [
          {
            label: "Custo Planejado",
            data: filteredTasks.map((t) => t.estimatedCost || 0), // Changed from t.plannedCost to t.estimatedCost
            backgroundColor: "#3b82f6",
          },
          {
            label: "Custo Real",
            data: filteredTasks.map((t) => t.actualCost || 0),
            backgroundColor: "#ef4444",
          },
        ],
      })
    }

    if (showHours) {
      createChart("customChartHours", chartType === "pie" || chartType === "doughnut" ? chartType : "bar", {
        labels: filteredTasks.map((t) => t.name),
        datasets: [
          {
            label: "Horas Planejadas",
            data: filteredTasks.map((t) => t.durationHours || 0),
            backgroundColor: "#10b981",
          },
          {
            label: "Horas Reais",
            data: filteredTasks.map((t) => t.actualHours || 0),
            backgroundColor: "#f59e0b",
          },
        ],
      })
    }
  }, 100)
})

// Initialize reports when project is selected
$("#selProjectReports")?.addEventListener("change", () => {
  showReportType("overview")
})

// Helper function for formatting dates (used in reports)
function formatDateBR(dateString) {
  if (!dateString) return ""
  const date = new Date(dateString)
  const day = String(date.getDate()).padStart(2, "0")
  const month = String(date.getMonth() + 1).padStart(2, "0")
  const year = date.getFullYear()
  return `${day}/${month}/${year}`
}
